#!/usr/bin/python
## initscan.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# runs the initial scans upon registration

import sys
import os
import datetime
import time
import getopt
import sqlite3
from subprocess import call

def main():
    try:
        call(["/opt/system/rdd/recon_alpha.sh", "fast"])
        call(["/opt/system/rdd/recon_bravo.py", "rogueonly"])
        call(["/opt/system/rdd/recon_charlie.py", "inital"])
        print "OK"
    except Exception as e:
        print e

if __name__ == "__main__":
    main()
    sys.exit(0)

