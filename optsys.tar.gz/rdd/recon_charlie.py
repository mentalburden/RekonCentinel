#!/usr/bin/python
## recon_charlie.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copyright and Intellectual Property Rights. For EYES Only!
#
# Recon Charlie is a script to scan a device that was found by a quick scan more intently and store those results
import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import xml.dom.minidom
import sqlite3
from core import functions
from subprocess import call

devnull = open(os.devnull, 'w')

try:
    mode = sys.argv[1]
except Exception, e:
    print "recon_charlie requires an argument: %s\n" % (e)
    sys.exit(0)

if mode == "roguerecon":
    try:
        dbfile = "/opt/system/rdd/hosts.db"
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
        digin_ip = {}
        digin_mac = {}
        cursor.execute('''SELECT DISTINCT ip, mac FROM hosts WHERE authorized = 0 ''')
        temp_index = 0
        for row in cursor:
            digin_ip[temp_index] = row['ip']
            digin_mac[temp_index] = row['mac']
            temp_index = temp_index + 1
        results = len(digin_ip)
        for devid in digin_ip:
            check_icmp_redir = functions.check_icmp_redirect(digin_ip[devid], digin_mac[devid])
            if check_icmp_redir is False:
                call(["/opt/system/rdd/get_hostname.py", digin_ip[devid]])
                call(["/usr/bin/nmap", "-O", "--send-eth", digin_ip[devid], "-oX", "/opt/system/rdd/roguerecon.xml"], stdout=devnull)
                call(["/opt/system/rdd/recon_bravo.py", "rogue", "roguerecon"])
                cmd = "/opt/system/rdd/cds_port_scanner.py %s normal" % (digin_ip[devid])
                ftemp = functions.cmdline(cmd)
        db.close()
    except Exception as e:
        print "%s\n" % (e)

elif mode == "initial":
    try:
        dbfile = "/opt/system/rdd/hosts.db"
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
        digin_ip = {}
        #cursor.execute('''SELECT DISTINCT ip FROM hosts WHERE authorized = 0 ''')
        cursor.execute('''SELECT DISTINCT ip FROM hosts''')
        temp_index = 0
        for row in cursor:
            digin_ip[temp_index] = row['ip']
            temp_index = temp_index + 1
        results = len(digin_ip)
        if results:
            status = "There were %s Devices Detected, please wait while we scan these more intently...." % (results)
            functions.set_systemstatus(status, "5")
        else:
            functions.set_systemstatus("There were No New Unauthorized Devices Detected.", "5")
        stat_count  = 1
        for devid in digin_ip:
            status = "Performing in depth probe on device %s of %s" % (stat_count, results)
            functions.set_systemstatus(status, "5")
            line1 = "SCANNING %s of" % (stat_count)
            line2 = "%s Devices" % (results)
            asd = functions.display_lcd(line1, line2)
            call(["/opt/system/rdd/get_hostname.py", digin_ip[devid]])
            call(["/usr/bin/nmap", "-O", "--send-eth", digin_ip[devid], "-oX", "/opt/system/rdd/initial.xml"], stdout=devnull)
            call(["/opt/system/rdd/recon_bravo.py", "initial", "initial"])
            cmd = "/opt/system/rdd/cds_port_scanner.py %s initial" % (digin_ip[devid])
            ftemp = functions.cmdline(cmd)
            stat_count = stat_count + 1
        db.close()
        functions.set_systemstatus("Initial Scans Complete", "5")
    except Exception as e:
        print "%s" % (e)

elif mode == "devrecon":
    try:
        dbfile = "/opt/system/rdd/hosts.db"
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
        digin_ip = {}
        cursor.execute('''SELECT DISTINCT ip FROM hosts''')
        temp_index = 0
        for row in cursor:
            digin_ip[temp_index] = row['ip']
            temp_index = temp_index + 1
        results = len(digin_ip)
        stat_count  = 1
        for devid in digin_ip:
            call(["/opt/system/rdd/get_hostname.py", digin_ip[devid]])
            #removing this for test - kinda overkill since we already scanned the device
            #call(["/usr/bin/nmap", "-O", "--send-eth", digin_ip[devid], "-oX", "/opt/system/rdd/devrecon.xml"], stdout=devnull)
            #call(["/opt/system/rdd/recon_bravo.py", "rogue", "devrecon"])
            cmd = "/opt/system/rdd/cds_port_scanner.py %s normal" % (digin_ip[devid])
            ftemp = functions.cmdline(cmd)
            stat_count = stat_count + 1
        db.close()
    except Exception as e:
        print "devrecon %s" % (e)

else: 
    print "YOUR ARUMENT IS NOT VALID"

