#!/usr/bin/python
import sys
sys.path.insert(0, "/opt/system/")
import os
import sqlite3
from core import functions


try:
    mode = sys.argv[1]
except Exception, e:
    print "recon_alpha an argument: %s\n" % (e)
    sys.exit(0)



try:
    dbfile = "/opt/system/rdd/hosts.db"
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    digin_ip = []

    if mode == "rogueonly":
        sql = "SELECT DISTINCT ip FROM hosts WHERE authorized = 0 AND whois = \"alert_rogue\""
        cursor.execute(sql)
        for row in cursor:
            digin_ip.append(row['ip'])
        for ip in digin_ip:
            severity = 1
            alert_type = "rogueonly"
            message = "Recon Sentinel has detected a Rogue Device!"
            functions.alert(message, severity, ip, alert_type)

    if mode == "ports":
        sql = "SELECT DISTINCT ip FROM hosts WHERE whois = \"alert_rogue\""
        cursor.execute(sql)
        for row in cursor:
            digin_ip.append(row['ip'])
        for ip in digin_ip:
            sql = "UPDATE hosts SET whois = \"\" WHERE ip = \"%s\"" % (ip)
            cursor.execute(sql)
            db.commit()
            sql = "SELECT * FROM ports WHERE ip = \"%s\"" % (ip)
            cursor.execute(sql)
            port = []
            for row in cursor:
                port.append(row['port'])
            for pn in port:
                service_info = functions.get_port_info(ip, pn, "service")
                service_name = functions.get_port_info(ip, pn, "name")
                if service_info == "":
                    service_info = "Unavailable"
                else:
                   service_info = service_info.title()
                if service_name == "":
                    service_name = "Unavailable"
                else:
                    service_name = service_name.upper()
                alert_msg = "%s (Description: %s) was found on port: %s" % (service_name, service_info, pn)
                alert_type = "rogueservice"
                severity = 2
                functions.alert(alert_msg, severity, ip, alert_type)
    db.close()
except Exception as e:
    print e
