#!/usr/bin/python
## rdd_daemon.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# rdd_daemon runs the recon processes in order on a repeating basis.
import sys
sys.path.insert(0, "/opt/system/")
import time
import daemon
from subprocess import call
from core import functions

def runrecon():
    try:
        count = 0
        while True:
            ftemp = functions.cmdline("/bin/rm -f /opt/system/rdd/*.xml")
            call(["/opt/system/rdd/recon_alpha.py", "fast"])
            call(["/opt/system/rdd/recon_bravo.py", "rogueonly", "fast_inventory"])
            call(["/opt/system/rdd/alert_rogues.py", "rogueonly"])
            call(["/opt/system/rdd/recon_charlie.py", "roguerecon"])
            call(["/opt/system/rdd/alert_rogues.py", "ports"])
            call(["/opt/system/rdd/get_state.py", ""])
            call(["/opt/system/rdd/host_sync.py", ""])
            call(["/opt/system/rdd/port_sync.py", ""])
            call(["/opt/system/alert/alert_sync.py", ""])
            call(["/opt/system/log/log_sync.py", ""])
            time.sleep(60)
            count = count + 1
            if count == 10:
                ftemp = functions.cmdline("/bin/rm -f /opt/system/rdd/*.xml")
                call(["/opt/system/rdd/recon_charlie.py", "devrecon"])
                call(["/opt/system/rdd/host_sync.py", ""])
                call(["/opt/system/rdd/port_sync.py", ""])
                call(["/opt/system/alert/alert_sync.py", ""])
                call(["/opt/system/log/log_sync.py", ""])
                count = 0
    except Exception as e:
        print "%s\n" % e

def run():
    with daemon.DaemonContext():
        runrecon()

if __name__ == "__main__":
    run()


