#!/usr/bin/python
## host_sync.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# Host sync will sync host changes between the recon sentinel and the API when the recon sentiel is unable to talk to the API


import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import xml.dom.minidom
import sqlite3
from core import functions
from axonchisel.handoff.object import Ax_Handoff
import requests
from requests.auth import HTTPBasicAuth

dbfile = "/opt/system/rdd/hosts.db"

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

try:
    sharedsecret = functions.get_ss()
    deviceid = functions.get_devid()
    password = functions.get_pass()
    cmd = "{\"cmd\": \"conntest\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    encdata = Ax_Handoff.encode(cmd, sharedsecret)
    api = functions.get_apiurl()
    url = "%s/_check/%s" % (api, encdata)
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
    connection_status = Ax_Handoff.decode(res.text, sharedsecret)
    if connection_status == "CONNECTED":
        port_trk = {}
        sync_trk = {}
        sql = "SELECT rowid, * FROM ports WHERE sync = 0"
        cursor.execute(sql)
        for row in cursor:
            #check if port exists:
            row_id = row['rowid']
            cmd = "{\"cmd\": \"checkport\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"password\": \"%s\"}" % (deviceid, row['ip'], row['port'], password)
            try:
                encdata = Ax_Handoff.encode(cmd, sharedsecret) 
                url = "%s/_check/%s" % (api, encdata)
                res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
                port_status = Ax_Handoff.decode(res.text, sharedsecret)
                if port_status == "PORT_EXISTS":
                    port_trk[row_id] = 1
                    print "Port exists"
                elif port_status == "PORT_DOES_NOT_EXIST":
                    port_trk[row_id] = 0
                    print "Port does not exist"
            except Exception as e:
                print "Issue checking if port exists with API: %s %s" % (e, cmd)

        for rwid in port_trk:
            if port_trk[rwid] == 1:
                sync_trk[rwid] = 1
                sql = "SELECT * FROM ports WHERE rowid = %s" % (rwid)
                cursor.execute(sql)
                row = cursor.fetchone()
                fields = row.keys()
                for key in fields:
                    sql2 = "SELECT %s FROM ports WHERE rowid = %s" % (key, rwid)
                    cursor.execute(sql)
                    for row3 in cursor:
                        if (key != "ip" and key != "sync"):
                            url = "%s/_update/portrecord" % (api)
                            portrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"password\": \"%s\"}" % (key, row[key], deviceid, row['ip'], row['port'], password)
                            api_response = functions.call_post_api(url, portrecord)
                            if api_response == "OK":
                                print "Got OK ACK, Record Updated"
                                if sync_trk[rwid] != 0:
                                    sync_trk[rwid] = 1
                            else:
                                print "There is an issue with your update of Field: %s Value: %s: %s" % (key, row[key], api_response)
                                sync_trk[rwid] = 0
            elif port_trk[rwid] == 0:
                sync_trk[rwid] = 1
                sql = "SELECT rowid, * FROM ports WHERE rowid = %s" % (rwid)
                cursor.execute(sql)
                for row in cursor:
                    url = "%s/_insert/ports" % (api)

                    portdata = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"protocol\": \"%s\", \"name\": \"%s\", \"state\": \"%s\", \"service\": \"%s\", \"info\": \"%s\", \"password\": \"%s\"}" % (deviceid, row['ip'], row['port'], row['protocol'], row['name'], row['state'], row['service'], row['info'], password)
                    api_response = functions.call_post_api(url, portdata)
                    if api_response == "OK":
                        print "Got OK ACK, Record Created"
                        if sync_trk[rwid] != 0:
                            sync_trk[rwid] = 1
                    else:
                        print "There is an issue with your request: %s" % (api_response)
                        sync_trk[rwid] = 0

        for rwidtrk in sync_trk:
            if sync_trk[rwidtrk] == 1:
                sql = "UPDATE ports SET sync = %s WHERE rowid = %s" % (sync_trk[rwidtrk], rwidtrk)
                cursor.execute(sql)
                db.commit()
            else:
                print "There was an issue updating the record, not syncd" 

        sync_trk = {}
        url = "%s/_update/rmport" % (api)
        sql = "SELECT rowid, * FROM ports WHERE sync = 2"
        cursor.execute(sql)
        for row in cursor:
            rwid = row['rowid']
            portdata = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"password\": \"%s\" }" % (deviceid, row['ip'], row['port'], password)
            api_response = functions.call_post_api(url, portdata)
            if api_response == "OK":
                print "Got OK ACK, Record Created"
                sync_trk[rwid] = 1
            else:
                print "There is an issue with your request: %s" % (api_response)
                sync_trk[rwid] = 0

        for rwidtrk in sync_trk:
            if sync_trk[rwidtrk] == 1:
                sql = "DELETE FROM ports WHERE rowid = %s" % (sync_trk[rwidtrk], rwidtrk)
                cursor.execute(sql)
                db.commit()
            else:
                print "There was an issue updating the record, not syncd" 


           
    else:
        print "not connected"
    db.close()

except Exception as e:
     print "Port Sync: Problem connecting to API %s" % (e)
            
    
