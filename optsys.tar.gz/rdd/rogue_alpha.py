#!/usr/bin/python

import sys
import os
import datetime
import getopt
import sqlite3

dbfile = "/opt/system/rdd/hosts.db"
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def main():
    try:
        auth_dev = {}
        ip = {}
        mac = {}
        hostname = {}
        os_vendor = {}
        os_family = {}
        os_name = {}
        mac_vendor = {}
        cursor.execute(''' SELECT rowid, * FROM hosts WHERE authorized = 0''')
        for row in cursor:
            row_id = row['rowid']
            ip[row_id] = row['ip']
            mac[row_id] = row['mac']    
            hostname[row_id] = row['hostname']
            os_vendor[row_id] = row['os_vendor']
            os_family[row_id] = row['os_family']
            os_name[row_id] = row['os_name']
            mac_vendor[row_id] = row['mac_vendor']
        for rowid1 in ip:
            print "The following device was seen on your network:\n System Name: %s \n Operating System Manufacturer: %s\n Operating System: %s\n Operating System Version (Best Guess): %s\n IP Address: %s\n MAC Address: %s\n Network Card Manufacturer: %s" % (hostname[rowid1], os_vendor[rowid1], os_family[rowid1], os_name[rowid1], ip[rowid1], mac[rowid1], mac_vendor[rowid1])
            cursor.execute('''SELECT * FROM ports WHERE ip = ?''', (ip[rowid1],))
            for row in cursor:
                print "Network Serivce Detected on Port: %s, Service Name: %s" % (row['port'], row['name'])
            rogue = raw_input("\nIs the above device allowed on your network? (Y/N) DEFAULT = N: ")
            if rogue == "Y":
                print "Setting device to authorized\n"
                auth_dev[rowid1] = 1
            elif rogue == "N":
                print "Setting device to rogue\n"
                auth_dev[rowid1] = 0
            else:
                print "DEFAULT - setting to rogue\n"
                auth_dev[rowid1] = 0

        for urid in auth_dev:
            sql_str = "UPDATE hosts SET authorized = %s where rowid = %s" % (auth_dev[urid], urid)
            cursor.execute(sql_str)
            db.commit()

    except Exception as e:
        print "%s\n" % e

if __name__ == "__main__":
    main()
    sys.exit(0)


