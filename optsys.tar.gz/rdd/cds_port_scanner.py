#!/usr/bin/python
import sys
sys.path.insert(0, "/opt/system/")
from scapy.all import *
import os
import sqlite3
from core import functions
import json
import xml.dom.minidom

try:
    ip = sys.argv[1]
    mode = sys.argv[2]
except Exception, e:
    print "cds_port_scanner requires arguments: %s\n" % (e)
    sys.exit(0)

def check_port(ip, port):
    dbfile = "/opt/system/rdd/hosts.db"
    try:
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (dbfile)
        sys.exit(0)

    cursor.execute(''' SELECT * FROM ports WHERE ip = ? AND port = ? ''', (ip, port))
    port_check = cursor.fetchone()
    db.close()
    return port_check

def check_alert_rogue(ip):
    dbfile = "/opt/system/rdd/hosts.db"
    try:
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (dbfile)
        sys.exit(0)
    sql = "SELECT * FROM hosts WHERE ip = \"%s\" AND whois = \"alert_rogue\"" % (ip)
    cursor.execute(sql)
    alert_rogue_check = cursor.fetchone()
    db.close()
    return alert_rogue_check


def insert_port_db(ip, pn, protocol, port_name, state, service_str, info_str):
    dbfile = "/opt/system/rdd/hosts.db"
    try:
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (dbfile)
        sys.exit(0)

    sync = 0;
    cursor.execute('''INSERT INTO ports VALUES (?, ?, ?, ?, ?, ?, ?, ?)''', (ip, pn, protocol, port_name, state, service_str, info_str, sync))
    db.commit()
    sql = "SELECT mac FROM hosts WHERE ip = \"%s\"" % (ip)
    cursor.execute(sql)
    for row in cursor:
        mac = row['mac']
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_insert/ports" % (api)

    port_name = port_name.upper()
    portdata = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"protocol\": \"%s\", \"name\": \"%s\", \"state\": \"%s\", \"service\": \"%s\", \"info\": \"%s\", \"mac\": \"%s\", \"password\": \"%s\"}" % (deviceid, ip, pn, protocol, port_name, state, service_str, info_str, mac, password)

    api_response = functions.call_post_api(url, portdata)

    if api_response == "OK":
        print "Got OK ACK, Record is synced, update db"
        sql = "UPDATE ports SET sync = 1 WHERE ip = \"%s\" AND port = \"%s\"" % (ip, pn)
        cursor.execute(sql)
        db.commit()
    else:
        print "There is an issue with your request: %s" % (api_response)

    db.close()

def port_scan2(ip, mode):
    cmd = "/bin/rm -f /opt/system/rdd/ports.xml"
    ftemp = functions.cmdline(cmd)
    cmd ="/usr/bin/nmap -sS -n -T4 %s --open -oX /opt/system/rdd/ports.xml" % (ip)
    ftemp = functions.cmdline(cmd)
    fname = "/opt/system/rdd/ports.xml"

    try:
        doc = xml.dom.minidom.parse(fname)
    except IOError:
        print "%s: error: file \"%s\" doesn't exist\n" % (fname, fname)

    except xml.parsers.expat.ExpatError:
        print "%s: error: file \"%s\" doesn't seem to be XML\n" % (fname, fname)

    for host in doc.getElementsByTagName("host"):

        try:
            ports = host.getElementsByTagName("ports")[0]
            ports = ports.getElementsByTagName("port")
        except:
            continue

        for port in ports:
            pn = port.getAttribute("portid")
            protocol = port.getAttribute("protocol")
            state_el = port.getElementsByTagName("state")[0]
            state = state_el.getAttribute("state")

            port_exists = check_port(ip, pn)
            if not port_exists:
                insert_port_db(ip, pn, "tcp", "", "open", "", "")
                cmd = "/usr/bin/nmap -sV -n -T3 -p%s %s -oX /opt/system/rdd/ports_only.xml" % (pn, ip)
                ftemp = functions.cmdline(cmd)
                cmd = "/opt/system/rdd/recon_bravo.py ports_only ports_only"
                ftemp = functions.cmdline(cmd)

                if mode != "initial":
                    alert_rogue = check_alert_rogue(ip)
                    if not alert_rogue:
                        service_info = functions.get_port_info(ip, pn, "service")
                        if service_info == "":
                            service_info = "Unavailable"
                        service_name = functions.get_port_info(ip, pn, "name")
                        alert_msg = "%s (Description: %s) was found on port: %s" % (service_name, service_info, pn)
                        alert_type = "rogueservice"
                        severity = 2
                        functions.alert(alert_msg, severity, ip, alert_type)


def is_port_open(ip, port):
    dst_ip = ip
    dst_port = int(port)
    src_port = RandShort()

    stealth_scan_resp = sr1(IP(dst=dst_ip)/TCP(sport=src_port,dport=dst_port,flags="S"),timeout=10, verbose=0)
    if(str(type(stealth_scan_resp))=="<type 'NoneType'>"):
        return False
    elif(stealth_scan_resp.haslayer(TCP)):
        if(stealth_scan_resp.getlayer(TCP).flags == 0x12):
            send_rst = sr(IP(dst=dst_ip)/TCP(sport=src_port,dport=dst_port,flags="R"),timeout=10, verbose=0)
            return True
        elif (stealth_scan_resp.getlayer(TCP).flags == 0x14):
            return False
        elif(stealth_scan_resp.haslayer(ICMP)):
            if(int(stealth_scan_resp.getlayer(ICMP).type)==3 and int(stealth_scan_resp.getlayer(ICMP).code) in [1,2,3,9,10,13]):
                return False

def check_current_port_status(ip):
    dbfile = "/opt/system/rdd/hosts.db"
    try:
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (dbfile)
        sys.exit(0)

    sql = "SELECT port FROM ports WHERE ip = \"%s\"" % (ip)
    cursor.execute(sql)
    myports = []
    for row in cursor:
        myports.append(row['port'])
    db.close()
    for port in myports:
        port_active = is_port_open(ip, port)
        if port_active is True:
            port_status = functions.get_port_info(ip, port, "state")
            if port_status == "closed":
                #cmd = "/usr/bin/nmap -sV -n -T4 -p%s %s -oX /opt/system/rdd/inventory.xml" % (port, ip)
                #ftemp = functions.cmdline(cmd)
                #cmd = "/opt/system/rdd/recon_bravo.py ports_only"
                #ftemp = functions.cmdline(cmd)
                functions.update_port_record(ip, "state", "open", row['port'])
                print "Port %s on %s went from closed to open" % (port, ip)
            else:
                print "Port %s on %s is still open" % (port, ip)
        else:
            port_status = functions.get_port_info(ip, port, "state")
            if port_status == "open":
                functions.update_port_record(ip, "state", "closed", port) # cant so this with DB already open
                print "Port %s on %s went from open to closed" % (port, ip)
            else:
                print "Port %s on %s still closed" % (port, ip)



#check_icmp_redirect = functions.check_icmp_redirect(ip)
#if check_icmp_redirect is False:
port_scan2(ip, mode)
check_current_port_status(ip)

sys.exit(0)

