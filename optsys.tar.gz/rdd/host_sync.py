#!/usr/bin/python
## host_sync.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# Host sync will sync host changes between the recon sentinel and the API when the recon sentiel is unable to talk to the API


import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import xml.dom.minidom
import sqlite3
from core import functions
from axonchisel.handoff.object import Ax_Handoff
import requests
from requests.auth import HTTPBasicAuth

dbfile = "/opt/system/rdd/hosts.db"

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def update_ip_record(ip, mac):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_update/iprecord" % (api)
    hostrecord = "{\"ip\": \"%s\", \"mac\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (ip, mac, deviceid, password)
    api_response = functions.call_post_api(url, hostrecord)
    if api_response == "OK":
        sql_string = "UPDATE hosts SET ip = \"%s\", sync = \"1\" WHERE mac = \'%s\'" % (ip, value, mac)
        cursor.execute(sql_string)
        db.commit()
        return True
    else:
        sql_string = "UPDATE hosts SET ip = \"%s\", sync = \"2\" WHERE mac = \'%s\'" % (ip, value, mac)
        cursor.execute(sql_string)
        db.commit()
        return False

try:
    sharedsecret = functions.get_ss()
    deviceid = functions.get_devid()
    password = functions.get_pass()
    cmd = "{\"cmd\": \"conntest\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    encdata = Ax_Handoff.encode(cmd, sharedsecret)
    api = functions.get_apiurl()
    url = "%s/_check/%s" % (api, encdata)
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
    connection_status = Ax_Handoff.decode(res.text, sharedsecret)
    if connection_status == "CONNECTED":
        host_trk = {}
        sync_trk = {}
        sql = "SELECT rowid, * FROM hosts WHERE sync = 2"
        cursor.execute(sql)
        for row in cursor:
            host_mac = row['mac']
            host_ip = row['ip']
            host_trk[host_mac] = host_ip
        
        for mmac in host_trk:
            sync_check = update_ip_record(host_trk[mmac], mmac)
            if sync_check:
                sql = "UPDATE hosts SET sync = '1' WHERE ip = \"%s\" AND mac = \"%s\"" % (host_trk[mmac], mmac)
                cursor.execute(sql)
                db.commit()

        host_trk = {}
        sync_trk = {}
        sql = "SELECT rowid, * FROM hosts WHERE sync = 0"
        cursor.execute(sql)
        for row in cursor:
            #check if hosts exists:
            row_id = row['rowid']

        sql = "SELECT rowid, * FROM hosts WHERE sync = 0"
        cursor.execute(sql)
        for row in cursor:
            #check if hosts exists:
            row_id = row['rowid']
            cmd = "{\"cmd\": \"checkhost\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"password\": \"%s\"}" % (deviceid, row['ip'], password)
            encdata = Ax_Handoff.encode(cmd, sharedsecret) 
            url = "%s/_check/%s" % (api, encdata)
            res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
            host_status = Ax_Handoff.decode(res.text, sharedsecret)
            if host_status == "HOST_EXISTS":
                host_trk[row_id] = 1
                print "Host exists"
            elif host_status == "HOST_DOES_NOT_EXIST":
                host_trk[row_id] = 0
                print "Host does not exist"

        for rwid in host_trk:
            if host_trk[rwid] == 1:
                sync_trk[rwid] = 1
                sql = "SELECT * FROM hosts WHERE rowid = %s" % (rwid)
                cursor.execute(sql)
                row = cursor.fetchone()
                fields = row.keys()
                for key in fields:
                    sql2 = "SELECT %s FROM hosts WHERE rowid = %s" % (key, rwid)
                    cursor.execute(sql)
                    for row3 in cursor:
                        if (key != "ip" and key != "sync" and key != "whois"):
                            url = "%s/_update/hostrecord" % (api)
                            hostrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"password\": \"%s\"}" % (key, row[key], deviceid, row['ip'], password)
                            api_response = functions.call_post_api(url, hostrecord)
                            if api_response == "OK":
                                print "Got OK ACK, Record Updated"
                                if sync_trk[rwid] != 0:
                                    sync_trk[rwid] = 1
                            else:
                                print "There is an issue with your update of Field: %s Value: %s: %s" % (key, row[key], api_response)
                                sync_trk[rwid] = 0
            elif host_trk[rwid] == 0:
                sync_trk[rwid] = 1
                sql = "SELECT rowid, * FROM hosts WHERE rowid = %s" % (rwid)
                cursor.execute(sql)
                for row in cursor:
                    url = "%s/_insert/hosts" % (api)
                    hostdata = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"mac\": \"%s\", \"hostname\": \"%s\", \"protocol\": \"%s\", \"os_name\": \"%s\", \"os_vendor\": \"%s\"," % (deviceid, row['ip'], row['mac'], row['hostname'], row['protocol'], row['os_name'], row['os_vendor'])
                    hostdata += "\"os_family\": \"%s\", \"os_accuracy\": \"%s\", \"os_gen\": \"%s\", \"timestamp\": \"%s\", \"state\": \"%s\", \"mac_vendor\": \"%s\"," % (row['os_family'], row['os_accuracy'], row['os_gen'], row['last_update'], row['state'], row['mac_vendor'])
                    hostdata += "\"whois_str\": \"%s\", \"authorized\": \"%s\", \"password\": \"%s\"}" % (row['whois'], row['authorized'], password)
                    api_response = functions.call_post_api(url, hostdata)
                    if api_response == "OK":
                        print "Got OK ACK, Record Created"
                        if sync_trk[rwid] != 0:
                            sync_trk[rwid] = 1
                    else:
                        print "There is an issue with your request: %s" % (api_response)
                        sync_trk[rwid] = 0

        for rwidtrk in sync_trk:
            if sync_trk[rwidtrk] == 1:
                sql = "UPDATE hosts SET sync = %s WHERE rowid = %s" % (sync_trk[rwidtrk], rwidtrk)
                cursor.execute(sql)
                db.commit()
            else:
                print "There was an issue updating the record, not syncd" 

    else:
        print "not connected"
    db.close()

except Exception as e:
     print "Host Sync: Problem connecting to API %s" % (e)
            
    
