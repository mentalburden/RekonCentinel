#!/usr/bin/python
## recon_alpha.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# 
import sys
sys.path.insert(0, "/opt/system/")
from core import functions

try:
    mode = sys.argv[1]
except Exception, e:
    print "recon_alpha an argument: %s\n" % (e)
    sys.exit(0)

local_ip = functions.get_local_ip()
#local_netmask = functions.get_local_netmask()
local_net = functions.get_local_network()



try:
    if mode == "fast":
        cmd = "/usr/bin/nmap -n -sn --send-eth --exclude %s %s -oX /opt/system/rdd/fast_inventory.xml" % (local_ip, local_net)
        functions.cmdline(cmd)
except Exception as e:
    print e
