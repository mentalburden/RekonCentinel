#!/bin/sh

RPID=$(ps uaxww | grep rdd_daemon.py | grep -v grep | grep python | awk '{print $2}')
echo "pid = $RPID\n"
if [ "$RPID" ]; then
    /bin/kill -9 $RPID
fi
exit 0

