#!/bin/bash
## recon_alpha.sh - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# Recon Alpha is a shell script that will scan at various intensities the network that the Recon Sentinel is attached to.
#v1.1

IP=$(/bin/hostname -I | /usr/bin/awk '{print $1}')
MASK=$(/sbin/ifconfig | /bin/grep 'inet addr' | /usr/bin/awk '{print $4}' | /bin/grep Mask | /usr/bin/awk -F: '/Mask:/{ print $2}')
NETWORK=$(/usr/bin/ipcalc -n $IP $MASK | /bin/grep Network | /usr/bin/awk '{print $2}')

cla=$(tr -d '\r' <<< "$1")

if [ "$cla" == "fast" ]; then
    /usr/bin/nmap -n -sP -T3 --exclude $IP $NETWORK -oX /opt/system/rdd/inventory.xml > /dev/null 2>&1
elif [ "$cla" == "normal" ]; then
    /usr/bin/nmap -n -sS -O -T4 -n --top-ports 15000 --exclude $IP $NETWORK -oX /opt/system/rdd/inventory.xml > /dev/null 2>&1
elif [ "$cla" == "initial" ]; then
    /usr/bin/nmap -n -sS -O -T4 -n --top-ports 15000 --exclude $IP $NETWORK -oX /opt/system/rdd/inventory.xml > /dev/null 2>&1
elif [ "$cla" == "hostnames" ]; then
    /usr/bin/nmap -n -sU -p 137 --script nbstat --exclude $IP $NETWORK -oX /opt/system/rdd/inventory.xml 
else
    echo "Need to supply and argument of fast, normal or deep"
fi

