#!/usr/bin/python
## get_state.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copyright and Intellectual Property Rights. For EYES Only!
#
# Checks if devices in inventory are up
#v1.1


import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import xml.dom.minidom
import sqlite3
from core import functions
from axonchisel.handoff.object import Ax_Handoff
import requests
from requests.auth import HTTPBasicAuth
from subprocess import call

devnull = open(os.devnull, 'w')
hostname = ""

dbfile = "/opt/system/rdd/hosts.db"

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def update_host_record(ip, field, value):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_update/hostrecord" % (api)
    hostrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"password\": \"%s\"}" % (field, value, deviceid, ip, password)
    api_response = functions.call_post_api(url, hostrecord)
    if api_response == "OK":
        sql_string = "UPDATE hosts SET %s = \"%s\", sync = \"1\" WHERE ip = \'%s\'" % (field, value, ip)
        cursor.execute(sql_string)
        db.commit()
        #print "Got OK ACK, Host Record Updated"
    else:
        print "There is an issue with your request: %s" % (api_response)
        sql_string = "UPDATE hosts SET %s = \"%s\", sync = \"0\" WHERE ip = \'%s\'" % (field, value, ip)
        cursor.execute(sql_string)
        db.commit()

ip_list = {}
try:
    ipsql = "SELECT rowid, ip FROM hosts"
    cursor.execute(ipsql)
    for row in cursor:
        row_id = row['rowid']
        ip_list[row_id] = str(row['ip'])
        #print row['ip']
except Exception , e:
    print e


for rwid in ip_list:
    ip = ip_list[rwid]
    devup = functions.is_device_up(ip)
    if devup == True:
        try:
            #print "%s is up" % (ip)
            sql = "UPDATE hosts SET state = \"up\" WHERE ip = \"%s\"" % (ip)
            cursor.execute(sql)
            db.commit()
            update_host_record(ip, 'state', 'up')
        except Exception, e:
            print e
    else:
        try:
            #print "%s is down" % (ip)
            sql = "UPDATE hosts SET state = \"down\" WHERE ip = \"%s\"" % (ip)
            cursor.execute(sql)
            db.commit()
            update_host_record(ip, 'state', 'down')
        except Exception, e:
            print e
sys.exit(0)   
