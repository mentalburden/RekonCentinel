#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import sqlite3
from core import functions


dbfile = "/opt/system/rdd/hosts.db"
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)


def update_host_record(ip, field, value):
    sql_string = "UPDATE hosts SET %s = \"%s\" WHERE ip = \'%s\'" % (field, value, ip)
    cursor.execute(sql_string)
    db.commit()

    #api
    deviceid = functions.get_devid()
    api = functions.get_apiurl()
    url = "%s/_update/hostrecord" % (api)
    hostrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\"}" % (field, value, deviceid, ip)
    api_response = functions.call_post_api(url, hostrecord)
    if api_response == "OK":
        print "Got OK ACK, Record Updated"
    else:
        print "There is an issue with your request: %s" % (api_response)

def main():
    try:
        auth_dev = {}
        ip = {}
        mac = {}
        hostname = {}
        os_vendor = {}
        os_family = {}
        os_name = {}
        mac_vendor = {}
        curr_auth_status = {}
        cursor.execute(''' SELECT rowid, * FROM hosts''')
        for row in cursor:
            row_id = row['rowid']
            ip[row_id] = row['ip']
            mac[row_id] = row['mac']    
            hostname[row_id] = row['hostname']
            os_vendor[row_id] = row['os_vendor']
            os_family[row_id] = row['os_family']
            os_name[row_id] = row['os_name']
            mac_vendor[row_id] = row['mac_vendor']
            curr_auth_status[row_id] = row['authorized']
        for rowid1 in ip:
            if curr_auth_status[rowid1] == 1:
                currently_authorized = "Device is currently an Authorized on your network."
            else:
                currently_authorized = "DEVICE IS AN UNAUTHORIZED ON YOUR NETWORK."
            print "The following device was seen on your network:\n Device ID: %s\n System Name: %s \n Operating System Manufacturer: %s\n Operating System: %s\n Operating System Version (Best Guess): %s\n IP Address: %s\n MAC Address: %s\n Network Card Manufacturer: %s" % (rowid1, hostname[rowid1], os_vendor[rowid1], os_family[rowid1], os_name[rowid1], ip[rowid1], mac[rowid1], mac_vendor[rowid1])
            cursor.execute('''SELECT * FROM ports WHERE ip = ?''', (ip[rowid1],))
            for row in cursor:
                print "    Network Service Detected on Port: %s, Service Name: %s" % (row['port'], row['name'])
            print "This %s\n\n" % (currently_authorized)
            rogue = raw_input("Is the above device allowed on your network? (Y/N) DEFAULT = Y: ")
            if rogue == "Y":
                print "Setting device to authorized\n"
                auth_dev[rowid1] = 1
            elif rogue == "N":
                print "Setting device to rogue\n"
                auth_dev[rowid1] = 0
            else:
                print "DEFAULT - setting to authorized\n"
                auth_dev[rowid1] = 1

        for urid in auth_dev:
            sql_str = "UPDATE hosts SET authorized = %s, sync = 0 where rowid = %s" % (auth_dev[urid], urid)
            cursor.execute(sql_str)
            db.commit()

    except Exception as e:
        print "%s\n" % e

if __name__ == "__main__":
    main()
    sys.exit(0)


