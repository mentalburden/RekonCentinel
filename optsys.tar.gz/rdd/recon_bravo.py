#!/usr/bin/python
## recon_bravo.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# Recon Bravo is the main script to read in the nmap xml file and perform rouge device and rouge port detection. Needs the inventory.xml file to function.
#v1.1

import sys
from scapy.all import *
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import xml.dom.minidom
import sqlite3
from core import functions
from axonchisel.handoff.object import Ax_Handoff
import requests
from requests.auth import HTTPBasicAuth

dbfile = "/opt/system/rdd/hosts.db"
try:
    mode = sys.argv[1]
    xmlfilename = sys.argv[2]
except Exception, e:
    print "recon_bravo requires and argument: %s\n" % (e)
    sys.exit(0)

if mode == "rogueonly":
    alert_type = "rogueonly"
elif mode == "rogue":
    alert_type = "rogue"
elif mode == "initial":
    alert_type = "initial"
elif mode == "ports_only":
    alert_type = "rogue"

else: 
    print "YOUR ARGUMENT IS INVALID"
    sys.exit(0)


try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def check_ip(ip):
    sql = "SELECT ip FROM hosts WHERE ip = \"%s\"" % (ip)
    cursor.execute(sql)
    ip_check = cursor.fetchone()
    return ip_check

def check_port(ip, port):
    cursor.execute(''' SELECT * FROM ports WHERE ip = ? AND port = ? AND sync = 1''', (ip, port))
    port_check = cursor.fetchone()
    return port_check

def check_temp_port(ip, port):
    cursor.execute(''' SELECT * FROM temp_ports WHERE ip = ? AND port = ?''', (ip, port))
    temp_port_check = cursor.fetchone()
    return temp_port_check

def check_rogue_ip(ip):
    cursor.execute(''' SELECT ip FROM hosts WHERE ip = ? AND authorized = 0''', (ip,))
    rogue_ip_check = cursor.fetchone()
    return rogue_ip_check

def check_authorized(ip, mac):
    cursor.execute(''' SELECT * FROM hosts WHERE ip = ? AND mac = ? AND authorized = 1''', (ip, mac))
    authorized_ip_check = cursor.fetchone()
    return authorized_ip_check

def check_mac(mac):
    sql = "SELECT mac FROM hosts WHERE mac = \"%s\"" % (mac)
    cursor.execute(sql)
    macstatus = cursor.fetchone()
    return macstatus

def check_rogue_mac(mac):
    sql = "SELECT mac FROM hosts WHERE mac = \"%s\" AND authorized = 0" % (mac)
    cursor.execute(sql)
    rogue_macstatus = cursor.fetchone()
    return rogue_macstatus

def check_auth_mac(mac):
    cursor.execute('''SELECT mac FROM hosts WHERE mac = ? AND authorized = 1''', (mac,))
    auth_macstatus = cursor.fetchone()
    return auth_macstatus

def check_alert_configs():
    cursor.execute('''SELECT * FROM alert_config''')
    alert_config_status = cursor.fetchone()
    return alert_config_status

def check_log_configs():
    cursor.execute('''SELECT * FROM log_config''')
    log_config_status = cursor.fetchone()
    return log_config_status

def check_app_configs():
    cursor.execute('''SELECT * FROM app_config''')
    app_config_status = cursor.fetchone()
    return app_config_status

def first_scan():
    cursor.execute('''SELECT * FROM hosts''')
    first_scan = cursor.fetchone()
    return first_scan

def insert_host_db(ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized):
    sync = 0
    try:
       #if not mac_vendor:
       mac_vendor = functions.get_mac_manufacturer(mac)
       cursor.execute('''INSERT INTO hosts (ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, last_update, state, mac_vendor, whois, authorized, sync) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized, sync))
       db.commit()
    except Exception as e:
        print "whoops: %s" % (e)


    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_insert/hosts" % (api)

    hostdata = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"mac\": \"%s\", \"protocol\": \"%s\", \"os_name\": \"%s\", \"os_vendor\": \"%s\"," % (deviceid, ip, mac, protocol, os_name, os_vendor)
    hostdata += "\"os_family\": \"%s\", \"os_accuracy\": \"%s\", \"os_gen\": \"%s\", \"timestamp\": \"%s\", \"state\": \"%s\", \"mac_vendor\": \"%s\"," % (os_family, os_accuracy, os_gen, timestamp, state, mac_vendor)
    hostdata += "\"whois_str\": \"%s\", \"authorized\": \"%s\", \"password\": \"%s\"}" % (whois_str, authorized, password)
    
    api_response = functions.call_post_api(url, hostdata) 
  
    if api_response == "OK":
        print "Got OK ACK, Record is synced, update db"
        sql = "UPDATE hosts SET sync = 1 WHERE ip = \"%s\" AND mac = \"%s\"" % (ip, mac)
        cursor.execute(sql)
        db.commit()
    else:
        print "There is an issue with _insert/hosts api: %s" % (api_response)

def update_host_record(ip, field, value):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_update/hostrecord" % (api)
    hostrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"password\": \"%s\"}" % (field, value, deviceid, ip, password)
    api_response = functions.call_post_api(url, hostrecord)
    if api_response == "OK":
        sql_string = "UPDATE hosts SET %s = \"%s\", sync = \"1\" WHERE ip = \'%s\'" % (field, value, ip)
        cursor.execute(sql_string)
        db.commit()
        print "Got OK ACK, Host Record Updated"
    else:
        print "There is an issue with your request: %s" % (api_response)
        sql_string = "UPDATE hosts SET %s = \"%s\", sync = \"0\" WHERE ip = \'%s\'" % (field, value, ip)
        cursor.execute(sql_string)
        db.commit()
 
def update_ip_record(ip, mac):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    sql = "SELECT ip FROM hosts WHERE mac = \"%s\"" % (mac)
    cursor.execute(sql)
    for row in cursor:
        oldip = row['ip']

    url = "%s/_update/iprecord" % (api)
    hostrecord = "{\"ip\": \"%s\", \"mac\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (ip, mac, deviceid, password)
    api_response = functions.call_post_api(url, hostrecord)
    if api_response == "OK":
        sql_string = "UPDATE hosts SET ip = \"%s\", sync = \"1\" WHERE mac = \"%s\"" % (ip, mac)
        cursor.execute(sql_string)
        db.commit()
        sql_string = "UPDATE ports SET ip = \"%s\" WHERE ip = \"%s\"" % (ip, oldip)
        cursor.execute(sql_string)
        db.commit()
        return oldip
    else:
        functions.mylog("There is an issue posting to _update/iprecord: %s" % (api_response))
        sql_string = "UPDATE hosts SET ip = \"%s\", sync = \"2\" WHERE mac = \'%s\'" % (ip, mac)
        cursor.execute(sql_string)
        db.commit()
        return False

def check_mac_ip(mac):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    sql = "SELECT ip FROM hosts WHERE mac = \"%s\"" % (mac)
    cursor.execute(sql)
    for row in cursor:
        oldip = row['ip']
    return oldip


def update_port_record(ip, field, value, port):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    sql = "SELECT mac FROM hosts WHERE ip = \"%s\"" % (ip)
    cursor.execute(sql)
    for row in cursor:
        mac = row['mac']
    api = functions.get_apiurl()
    url = "%s/_update/portrecord" % (api)
    portrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"mac\": \"%s\", \"password\": \"%s\"}" % (field, value, deviceid, ip, port, mac, password)
    api_response = functions.call_post_api(url, portrecord)
    if api_response == "OK":
        sql_string = "UPDATE ports SET %s = \"%s\", sync = \"1\" WHERE ip = \'%s\' AND port = \"%s\"" % (field, value, ip, port)
        cursor.execute(sql_string)
        db.commit()
        print "Got OK ACK, Record Updated"
    else:        
        sql_string = "UPDATE ports SET %s = \"%s\", sync = \"0\" WHERE ip = \'%s\' AND port = \"%s\"" % (field, value, ip, port)
        cursor.execute(sql_string)
        db.commit()
        print "There is an issue with your request: %s" % (api_response)
 

def remove_all_ports(ip):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_update/rmallports" % (api)
    delports = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"password\": \"%s\"}" % (deviceid, ip, password)
    api_response = functions.call_post_api(url, delports)
    if api_response == "OK":
        sql_string = "DELETE from ports WHERE ip = \'%s\'" % (ip)
        cursor.execute(sql_string)
        db.commit()
        print "Got OK ACK, Record Updated"
    else:
        print "There is an issue with your request: %s" % (api_response)
        sql_string = "UPDATE ports SET sync = \"2\" WHERE ip = \'%s\'" % (ip)
        cursor.execute(sql_string)
        db.commit()

def remove_all_temp_ports(ip):
    sql_string = "DELETE from temp_ports WHERE ip = \'%s\'" % (ip)
    cursor.execute(sql_string)
    db.commit()

def remove_ports(ip, port):
   #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_update/rmport" % (api)
    delport = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"password\": \"%s\"}" % (deviceid, ip, port, password)
    api_response = functions.call_post_api(url, delport)
    if api_response == "OK":
        print "Got OK ACK, Record Updated"
        sql_string = "DELETE from ports WHERE ip = \'%s\' AND port = \'%s\'" % (ip, port)
        cursor.execute(sql_string)
        db.commit()
    else:
        sql_string = "UPDATE ports set sync = \"2\" WHERE ip = \'%s\' AND port = \'%s\'" % (ip, port)
        cursor.execute(sql_string)
        db.commit()
        print "There is an issue with your request: %s" % (api_response)


def remove_temp_ports(ip, port):
    sql_string = "DELETE from temp_ports WHERE ip = \'%s\' AND port = \'%s\'" % (ip, port)
    cursor.execute(sql_string)
    db.commit()

def insert_port_db(ip, pn, protocol, port_name, state, service_str, info_str):
    sync = 0;
    cursor.execute('''INSERT INTO ports VALUES (?, ?, ?, ?, ?, ?, ?, ?)''', (ip, pn, protocol, port_name, state, service_str, info_str, sync))
    db.commit()
    print "INSERT PORT DB %s, %s, %s, %s, %s, %s, %s, %s" % (ip, pn, protocol, port_name, state, service_str, info_str, sync)
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_insert/ports" % (api)

    portdata = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"protocol\": \"%s\", \"name\": \"%s\", \"state\": \"%s\", \"service\": \"%s\", \"info\": \"%s\", \"password\": \"%s\"}" % (deviceid, ip, pn, protocol, port_name, state, service_str, info_str, password)
    
    api_response = functions.call_post_api(url, portdata) 
  
    if api_response == "OK":
        print "Got OK ACK, Record is synced, update db"
        sql = "UPDATE ports SET sync = 1 WHERE ip = \"%s\" AND port = \"%s\"" % (ip, pn)
        cursor.execute(sql)
        db.commit()
    else:
        print "There is an issue with your request: %s" % (api_response)
 

def insert_temp_port_db(ip, pn, protocol, port_name, state, service_str, info_str):
    cursor.execute('''INSERT INTO temp_ports VALUES (?, ?, ?, ?, ?, ?, ?)''', (ip, pn, protocol, port_name, state, service_str, info_str))
    db.commit()

def main(fname):

    #GET CONFIGS
    try:
        scan_iplist = {}
        alert_config_status = check_alert_configs()
        debug_logs = 0
        if alert_config_status is None:
            raise Exception('No Alert Configuraion data present... exiting')
        else:
            cursor.execute('''SELECT * FROM alert_config''')
            for row in cursor:
                alert_rogue_devices = row['rogue_devices']
                alert_hostname_change = row['hostname_change']
                alert_protocol_change = row['protocol_change']
                alert_os_name_change = row['os_name_change']
                alert_os_family_change = row['os_family_change']
                alert_os_vendor_change = row['os_vendor_change']
                alert_os_accuracy_change = row['os_accuracy_change']
                alert_os_gen_change = row['os_gen_change']
                alert_state_change = row['state_change']
                alert_rogue_ports = row['rogue_ports']
                alert_port_protocol_change = row['port_protocol_change']
                alert_port_name_change = row['port_name_change']
                alert_port_state_change = row['port_state_change']
                alert_port_service_change = row['port_service_change']
    except ValueError as err:
        print(err.args)

    try:
        log_config_status = check_log_configs()
        if log_config_status is None:
            raise Exception('No Log Configuration data present... exiting')
        else:
            cursor.execute('''SELECT * FROM log_config''')
            for row in cursor:
                log_rogue_devices = row['rogue_devices']
                log_hostname_change = row['hostname_change']
                log_protocol_change = row['protocol_change']
                log_os_name_change = row['os_name_change']
                log_os_family_change = row['os_family_change']
                log_os_vendor_change = row['os_vendor_change']
                log_os_accuracy_change = row['os_accuracy_change']
                log_os_gen_change = row['os_gen_change']
                log_state_change = row['state_change']
                log_rogue_ports = row['rogue_ports']
                log_port_protocol_change = row['port_protocol_change']
                log_port_name_change = row['port_name_change']
                log_port_state_change = row['port_state_change']
                log_port_service_change = row['port_service_change']
    except ValueErrpr as err:
        print(err.args)

    try:
        app_config_status = check_app_configs()
        if app_config_status is None:
            raise Exception('No Application Configuration data present... exiting')
        else:
            cursor.execute('''SELECT * FROM app_config''')
            for row in cursor:
                initial_scan = row['initial_scan']
    except ValueError as err:
        print(err.args)

    #END GET CONFIGS ------------------------------------------------------------------------


    #PARSE XML FILE ------------------------------------------------------------------------

    try:
        doc = xml.dom.minidom.parse(fname)
        firstscan = first_scan()
    except IOError:
        print "%s: error: file \"%s\" doesn't exist\n" % (fname, fname)

    except xml.parsers.expat.ExpatError:
        print "%s: error: file \"%s\" doesn't seem to be XML\n" % (fname, fname)

    for host in doc.getElementsByTagName("host"):
        try:
            address = host.getElementsByTagName("address")[0]
            ip = address.getAttribute("addr")
            protocol = address.getAttribute("addrtype")
        except:
            continue

        try:
            mac_address = host.getElementsByTagName("address")[1]
            mac = mac_address.getAttribute("addr")
            mac = mac.rstrip()
            mac_vendor = mac_address.getAttribute("vendor")
        except:
            mac = ""
            mac_vendor = ""

        try:
            status = host.getElementsByTagName("status")[0]
            state = status.getAttribute("state")
        except:
            state = ""

        try:
            os_el = host.getElementsByTagName("os")[0]
            os_match = os_el.getElementsByTagName("osmatch")[0]
            os_name = os_match.getAttribute("name")
            os_accuracy = os_match.getAttribute("accuracy")
            os_class = os_el.getElementsByTagName("osclass")[0]
            os_family = os_class.getAttribute("osfamily")
            os_vendor = os_class.getAttribute("vendor")
            os_gen = os_class.getAttribute("osgen")
        except:
            os_name = ""
            os_accuracy = ""
            os_family = ""
            os_vendor = ""
            os_gen = ""

        try:
            timestamp = host.getAttribute("endtime")
        except:
            timestamp = ""

       # try:
       #     hostscript = host.getElementsByTagName("hostscript")[0]
       #     script = hostscript.getElementsByTagName("script")[0]
       #     id = script.getAttribute("id")
       #     if id == "whois":
       #         
       #         whois_str = script.getAttribute("output")
       #     else:
       #         whois_str = ""

        #except:
        #    whois_str = ""
        
        #ROGUE DEVICE DETECTION -------------------------------------------------------------------
        try:
            if mode != "ports_only":
                scan_iplist[ip] = mac
                ipcheck = check_ip(ip)  #check if we have seen this IP
                device_info = "IP Address: %s, MAC Address: %s, Operating System: %s" % (ip, mac, os_family)
                if ipcheck: #Yes, we have seen the IP
                    #Initialize comparison vars
                    mac_changed = 0
                    ip_changed = 0
                    protocol_changed = 0
                    os_name_changed = 0
                    os_accuracy_changed = 0
                    os_vendor_changed = 0
                    os_family_changed = 0
                    os_gen_changed = 0
                    state_changed = 0
                    authorized = 0
                    if debug_logs == 1:
                        functions.mylog("Checking existing record for %s..," % (device_info))
                
                    #initialize arrays for values
                    curr_mac = {}
                    curr_protocol = {}
                    curr_os_name = {}
                    curr_os_accuracy = {}
                    curr_os_vendor = {}
                    curr_os_family = {}
                    curr_os_gen = {}
                    curr_state = {}
                    curr_ip = {}
                    curr_auth = {}

                    #populate comparison vars
                    cursor.execute(''' SELECT rowid, * FROM hosts WHERE ip = ?''', (ip,))
                    for row in cursor:
                        row_id = row['rowid']
                        curr_ip[row_id] = str(row['ip'])
                        curr_mac[row_id] = str(row['mac'])
                        curr_protocol[row_id] = str(row['protocol'])
                        curr_os_name[row_id] = str(row['os_name'])
                        curr_os_accuracy[row_id] = str(row['os_accuracy'])
                        curr_os_vendor[row_id] = str(row['os_vendor'])
                        curr_os_family[row_id] = str(row['os_family'])
                        curr_os_gen[row_id] = str(row['os_gen'])
                        curr_state[row_id] = str(row['state'])
                        curr_auth[row_id] = row['authorized']
    
                    for rwid in curr_ip:
                        test_mac = curr_mac[rwid]
                        test_protocol = curr_protocol[rwid]
                        test_os_name = curr_os_name[rwid]
                        test_os_accuracy = curr_os_accuracy[rwid]
                        test_os_vendor = curr_os_vendor[rwid]
                        test_os_family = curr_os_family[rwid]
                        test_os_gen = curr_os_gen[rwid]
                        test_state = curr_state[rwid]
                        dev_authorized = curr_auth[rwid]
                        
                        # MAC ADDRESS TESTS
                        if mac == test_mac:
                            if debug_logs == 1:
                                functions.mylog("MAC Address %s  matches for %s" % (mac, ip))
                            if dev_authorized == 0:
                                #We already know this device is rogue, so just log
                                functions.mylog("Previously Detected Rogue Device - %s" % (device_info))
                        else:
                            if debug_logs == 1:
                                functions.mylog("MAC has CHANGED.. OLD: %s / NEW: %s  for : %s" % (test_mac, mac, ip))
                            mac_changed = 1
                            checkmac = check_mac(mac)
                            if checkmac is None:
                                #Device is Rogue unless it's an ICMP REDIRECT
                                check_for_icmp_redirect = functions.check_icmp_redirect(ip, mac)
                                if check_for_icmp_redirect is True:
                                    functions.mylog("Recon Sentinel has detected an ICMP Redirect on IP: %s" % (ip))
                                elif alert_rogue_devices == 1:
                                    #cmd = "/opt/system/rdd/get_hostname.py %s" % (ip)
                                    #ftemp = functions.cmdline(cmd)
                                    whois_str = "alert_rogue"
                                    #severity = 1
                                    #functions.alert("Rogue Device Detected1!!! IP: %s" % (device_info), severity, ip, alert_type)
                                    authorized = 0
                                    #functions.mylog("Inserting Rogue Device -  IP: %s" % (device_info))
                                    insert_host_db(ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized)
                                    #Log
                                if log_rogue_devices == 1:
                                    functions.mylog("Rogue Device Detected!!! IP: %s" % (device_info))
                                    #Insert
                            else:
                                #mac has changed, but the device is known, check for ICMP Redirect and if its a previously detected rogue...
                                check_for_icmp_redirect = functions.check_icmp_redirect(ip, mac)
                                if check_for_icmp_redirect is True:
                                    #ICMP Redirect - do not update anything, just log and maybe alert
                                    functions.mylog("Recon Sentinel has detected an ICMP Redirect on IP: %s" % (ip))
                                #elif check_for_icmp_redirect is False:
                                else:
                                    check_known_rogue = check_rogue_mac(mac)
                                    if check_known_rogue is None:
                                        packet = IP(dst=ip)/ICMP()
                                        resp = sr1(packet, timeout = 1, verbose = 0)
                                        if resp:
                                            icmp_type = resp[0][IP].type
                                            icmp_src_ip = resp[0].src
                                        #device is not a known rogue, but it is a known and authed device, so update its record - most likely DHCP lease renew with new IP
                                        functions.mylog("Authorized device IP Change for: %s ICMP TYPE: %s, SRC IP: %s" % (device_info, icmp_type, icmp_src_ip))
                                        update_host_record(ip, 'mac', mac)
                                        #since the ports will change, need to remove and repopulate
                                        #Not sure the above logic is working correctly. Need to look into copying the info for ports over - or change the ports with the old ip to new ip
                                        #if there is high confidence in the logic
                                        functions.mylog("Removing all known ports for %s" % (device_info))
                                        remove_all_ports(ip)
                                    else:
                                        #We already know this device is rogue, so just log
                                        functions.mylog("Previously Detected Rogue Device -  %s" % (device_info))
                
                       #PARSE OTHER HOST INFO ------------------------------------------------------------------------
     
                        if mode != "rogueonly":
                            # PROTOCOL TESTS
                            if protocol == test_protocol:
                                if debug_logs == 1:
                                    functions.mylog("Protocol %s matches for IP %s" % (protocol, ip))
                            else:
                                protocol_changed = 1
                                if mac_changed == 0:
                                    if alert_protocol_change == 1:
                                       severity = 4
                                       functions.alert("PROTOCOL has changed from %s to %s for %s" % (test_protocol, protocol, device_info), severity, ip, alert_type)
                                    if log_protocol_change == 1:
                                       functions.mylog("PROTOCOL has changed from %s to %s for %s" % (test_protocol, protocol, device_info))
                                    update_host_record(ip, 'protocol', protocol) 
                                else:
                                    if log_protocol_change == 1:
                                        functions.mylog("PROTOCOL has changed from %s to %s for: %s \n" % (test_protocol, protocol, device_info))
                                    update_host_record(ip, 'protocol', protocol) 
         
                            # OS NAME TESTS - OS NAME IS NOT RELIABLE
                            if os_name == test_os_name:
                                if debug_logs == 1:
                                    functions.mylog("OS NAME %s matches for IP %s" % (os_name, ip))
                            else:
                                os_name_changed = 1
                                if mac_changed == 0:
                                    if alert_os_name_change == 1:
                                        severity = 4
                                        #This is not a reliable test
                                        functions.alert("OS NAME has changed from %s to %s for %s" % (test_os_name, os_name, device_info), severity, ip, alert_type)
                                    if log_os_name_change == 1:
                                        functions.mylog("OS NAME has changed from %s to %s for %s" % (test_os_name, os_name, device_info))
                                    update_host_record(ip, 'os_name', os_name) 
                                else:
                                    if log_os_name_change == 1:
                                        functions.mylog("OS NAME has changed from %s to %s for %s" % (test_os_name, os_name, device_info))
                                    update_host_record(ip, 'os_name', os_name) 
                           
                            # OS VENDOR
                            if os_vendor == test_os_vendor:
                                if debug_logs == 1:
                                    functions.mylog("OS VENDOR %s matches for IP %s" % (os_vendor, ip))
                            else:
                                os_vendor_changed = 1
                                if mac_changed == 0:
                                    if alert_os_vendor_change == 1:
                                        severity = 4
                                    if log_os_vendor_change == 1:
                                        functions.mylog("OS VENDOR has changed from %s to %s for %s" % (test_os_vendor, os_vendor, device_info))
                                    update_host_record(ip, 'os_vendor', os_vendor) 
                                else:
                                    if log_os_vendor_change == 1:
                                        functions.mylog("OS VENDOR has changed from %s to %s for %s" % (test_os_vendor, os_vendor, device_info))
                                    update_host_record(ip, 'os_vendor', os_vendor) 
        
                            # OS FAMILY
                            if os_family == test_os_family:
                                if debug_logs == 1:
                                    functions.mylog("OS FAMILY %s matches for IP %s" % (os_family, ip))
                            else:
                                os_family_changed = 1
                                if mac_changed == 0:
                                    if alert_os_family_change == 1:
                                        severity = 4
                                    if log_os_family_change == 1:
                                        functions.mylog("OS FAMILY has changed from %s to %s for %s" % (test_os_family, os_family, device_info))
                                    update_host_record(ip, 'os_family', os_family) 
                                else:
                                    if log_os_family_change == 1:
                                        functions.mylog("OS FAMILY has changed from %s to %s for %s" % (test_os_family, os_family, device_info))
                                    update_host_record(ip, 'os_family', os_family) 
    
    
                            # OS ACCURACY TESTS - NOT RELIABLE
                            if os_accuracy == test_os_accuracy:
                                if debug_logs == 1:
                                    functions.mylog("OS Detection Accuracy of %s matches for IP %s" % (os_accuracy, ip))
                            else:
                                os_accuracy_changed = 1
                                if mac_changed == 0:
                                    if alert_os_accuracy_change == 1:
                                        severity = 4
                                        functions.alert("OS DETECTION ACCURACY has changed from %s to %s for %s" % (test_os_accuracy, os_accuracy, device_info), severity, ip, alert_type)
                                    if log_os_accuracy_change == 1:
                                        functions.mylog("OS DETECTION ACCURACY has changed from %s to %s for %s" % (test_os_accuracy, os_accuracy, device_info))
                                    update_host_record(ip, 'os_accuracy', os_accuracy) 
                                else:
                                    if log_os_accuracy_change == 1:
                                        functions.mylog("OS DETECTION ACCURACY has changed from %s to %s for %s" % (test_os_accuracy, os_accuracy, device_info))
                                    update_host_record(ip, 'os_accuracy', os_accuracy) 
    
                            # OS GENERATION TESTS
                            if os_gen == test_os_gen:
                                if debug_logs == 1:
                                    functions.mylog("OS GENERATION of %s matches for IP %s" % (os_gen, ip))
                            else:
                                os_gen_changed = 1
                                if mac_changed == 0:
                                    if alert_os_gen_change == 1:
                                        severity = 4
                                        functions.alert("OS GENERATION has changed from %s to %s for %s" % (test_os_gen, os_gen, device_info), severity, ip, alert_type)
                                    if log_os_gen_change == 1:
                                        functions.mylog("OS GENERATION has changed from %s to %s for %s" % (test_os_gen, os_gen, device_info))
                                    update_host_record(ip, 'os_gen', os_gen) 
                                else:
                                    if log_os_gen_change == 1:
                                        functions.mylog("OS GENERATION has changed from %s to %s for %s" % (test_os_gen, os_gen, device_info))
                                    update_host_record(ip, 'os_gen', os_gen) 
    
                            # DEVICE STATE TESTS
                            if state == test_state:
                                if debug_logs == 1:
                                    functions.mylog("DEVICE STATE of %s matches for IP %s" % (state, ip))
                            else:
                                state_changed = 1
                                if mac_changed == 0:
                                    if alert_state_change == 1:
                                        severity = 4
                                        functions.alert("DEVICE STATE has changed from %s to %s for %s" % (test_state, state, device_info), severity, ip, alert_type)
                                    if log_state_change == 1:
                                        functions.mylog("DEVICE STATE has changed from %s to %s for %s" % (test_state, state, device_info))
                                    update_host_record(ip, 'state', state) 
                                else:
                                    if log_os_gen_change == 1:
                                        functions.mylog("DEVICE STATE has changed from %s to %s for %s" % (test_state, state, device_info))
                                    update_host_record(ip, 'state', state) 

                #We have not seen this IP before, so process accordingly 
                else:
                    if firstscan is None: #No info in hosts database, so must be a first time scan of network
                        check_for_icmp_redirect = functions.check_icmp_redirect(ip, mac)
                        if check_for_icmp_redirect is True:
                            functions.mylog("Recon Sentinel has detected an ICMP Redirect on New IP: %s" % (ip))
                        else:
                            whois_str = ""
                            functions.mylog("New Device Detected - inserting record for %s" % (device_info))
                            authorized = 1
                            insert_host_db(ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized)
                    else:
                        check_known_mac = check_auth_mac(mac)
                        if check_known_mac:
                            #we know this device and it's authorized - it is a virtual?
                            firstip = check_mac_ip(mac)
                            firstipup = os.system("ping -c 2 -w 2 " + firstip  + " > /dev/null 2>&1")
                            if firstipup == 0: #host is up
                                #check for ICMP Redirect
                                check_for_icmp_redirect = functions.check_icmp_redirect(ip, mac)
                                if check_for_icmp_redirect is True:
                                    #ICMP Redirect - Log and do nothing
                                    functions.mylog("Recon Sentinel has detected an ICMP Redirect on New IP: %s" % (ip))
                                else:    
                                    #New IP  is most likely a VIP, log as such, insert as rogue
                                    whois_str = "alert_rogue"
                                    #severity = 1
                                    #functions.alert("Rogue Device Detected2 on %s - Looks like a virtual IP as %s and %s share MAC address %s" % (ip, ip, firstip, mac), severity, ip, alert_type)
                                    functions.mylog("Rogue Device Detected on %s - Looks like a virtual IP as %s and %s share MAC address %s" % (ip, ip, firstip, mac))
                                    authorized = 0
                                    insert_host_db(ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized)
                            else:
                                #Old IP is not up, most likely a DHCP address change, but need to check for icmp redirectm then update and log
                                check_for_icmp_redirect = functions.check_icmp_redirect(ip, mac)
                                if check_for_icmp_redirect is True:
                                    #ICMP Redirect - do not update anything, just log and maybe alert
                                    functions.mylog("Recon Sentinel has detected an ICMP Redirect on IP: %s" % (ip))
                                #elif check_for_icmp_redirect is False:
                                else:
                                    oldip = update_ip_record(ip, mac)
                                    functions.mylog("Authorized device IP Change for: %s to %s for MAC: %s" % (ip, oldip, mac))
                        else:
                            check_known_rogue = check_rogue_mac(mac)
                            if check_known_rogue is None:
                                check_for_icmp_redirect = functions.check_icmp_redirect(ip, mac)
                                if check_for_icmp_redirect is True:
                                    functions.mylog("Recon Sentinel has detected an ICMP Redirect on IP: %s" % (ip))
                                else:
                                    whois_str = "alert_rogue"
                                    #severity = 1
                                    #functions.alert("Rogue Device Detected3...: %s" % (device_info), severity, ip, alert_type)
                                    functions.mylog("Rogue Device Detected...: %s" % (device_info))
                                    authorized = 0
                                    insert_host_db(ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized)
                            else:            
                                functions.mylog("Previously Detected Rogue Device - %s" % (device_info))

        except Exception, e:
            print "%s: exception during insert into table hosts\n" % (e)
            continue
        

        #Port Stuff
        #This data only present if mode != rogueonly
        if mode == "ports_only": 
            try:
                ports = host.getElementsByTagName("ports")[0]
                ports = ports.getElementsByTagName("port")
            except:
                if debug_logs == 1:
                    functions.mylog("%s: host %s has no open ports" % (mac, ip))
                continue

            for port in ports:
                pn = port.getAttribute("portid")
                protocol = port.getAttribute("protocol")
                state_el = port.getElementsByTagName("state")[0]
                state = state_el.getAttribute("state")

                try:
                    service = port.getElementsByTagName("service")[0]
                    port_name = service.getAttribute("name")
                    product_descr = service.getAttribute("product")
                    product_ver = service.getAttribute("version")
                    product_extra = service.getAttribute("extrainfo")
                except:
                    service = ""
                    port_name = ""
                    product_descr = ""
                    product_ver = ""
                    product_extra = ""
    
                service_str = "%s %s %s" % (product_descr, product_ver, product_extra)
    
                info_str = ""
    
                for i in (0, 1):
                    try:
                        script = port.getElementsByTagName("script")[i]
                        script_id = script.getAttribute("id")
                        script_output = script.getAttribute("output")
                    except:
                        script_id = ""
                        script_output = ""
    
                    if script_id != "" and script_output != "":
                        info_str += "%s: %s\n" % (script_id, script_output)
    
                try:
                    #insert_temp_port_db(ip, pn, protocol, port_name, state, service_str, info_str)
                    update_port_record(ip, "protocol", protocol, pn)
                    update_port_record(ip, "name", port_name, pn)
                    update_port_record(ip, "state", state, pn)
                    update_port_record(ip, "service", service_str, pn)
                    update_port_record(ip, "info", info_str, pn)
    
                except Exception, e:
                    print "%s: exception during insert into table ports\n" % (e)
                    continue
       
    try:
        #if mode != ("rogueonly" or "noports"):
        if mode == False:
            #Check if ports have been removed
            current_ip = {}
            current_port = {}
            current_protocol = {}
            current_portname = {}
            current_state = {}
            current_service = {}
            current_info = {}
            cursor.execute('''SELECT rowid, * FROM ports''')
            are_there_ports = cursor.fetchone()
            if are_there_ports:
                cursor.execute('''SELECT rowid, * FROM ports''')
                for row in cursor:
                    row_id = row['rowid']
                    current_ip[row_id] = str(row['ip'])
                    current_port[row_id] = str(row['port'])
                    current_protocol[row_id] = str(row['protocol'])
                    current_portname[row_id] = str(row['name'])
                    current_state[row_id] = str(row['state'])
                    current_service[row_id] = str(row['service'])
                    current_info[row_id] = str(row['info'])
                for asd1 in current_ip:
                    checktempport = check_temp_port(current_ip[asd1], current_port[asd1])
                    if checktempport is None:
                        #Port does not exist in current scan - log at minimum, remove from port list, see if device is in current scan
                        if current_ip[asd1] in scan_iplist:
                            #check if host is up
                            pinghost = current_ip[asd1]
                            pingresponse = os.system("ping -c 2 -w 2 " + pinghost  + " > /dev/null 2>&1")
                            if pingresponse == 0: #host is up - so log and remove open ports
                                functions.mylog("PORT %s - %s is no longer open on IP: %s" % (current_port[asd1], current_portname[asd1], current_ip[asd1])) 
                                update_port_record(current_ip[asd1], "state", "closed", current_port[asd1])
                                print "update port record"
                                #remove_ports(current_ip[asd1], current_port[asd1])
                                
        
            #Check if ports have beed added    
            temp_ip = {}
            temp_port = {}
            temp_protocol = {}
            temp_portname = {}
            temp_state = {}
            temp_service = {}
            temp_info = {}
            cursor.execute('''SELECT rowid, * FROM temp_ports''')
            for row in cursor:
                row_id = row['rowid']
                temp_ip[row_id] = str(row['ip'])
                temp_port[row_id] = str(row['port'])
                temp_protocol[row_id] = str(row['protocol'])
                temp_portname[row_id] = str(row['name'])
                temp_state[row_id] = str(row['state'])
                temp_service[row_id]= str(row['service'])
                temp_info[row_id] = str(row['info'])
    
            for asd in temp_ip:
                portcheck = check_port(temp_ip[asd], temp_port[asd])
                if portcheck is None:
                    #Port does not exist check if it is open then - alert and add?
                    if temp_state[asd] == "open":
                        if firstscan is None:
                            functions.mylog("Initial Network Service Detected on Port %s %s for %s" % (temp_port[asd], temp_portname[asd], temp_ip[asd]))
                        else:
                            severity = 2
                            if (alert_type == "initial"):
                                service_alert_type = alert_type
                            else:
                                service_alert_type = "rogueservice"
                            #cmd = "/opt/system/rdd/get_hostname.py %s" % (ip)
                            #ftemp = functions.cmdline(cmd)
                            functions.alert("New Network Service Detected on Port %s, Service Name:  %s for IP: %s" % (temp_port[asd], temp_portname[asd], temp_ip[asd]), severity, temp_ip[asd], service_alert_type)
                            print "New Network Service Detected on Port %s, Service Name:  %s for IP: %s" % (temp_port[asd], temp_portname[asd], temp_ip[asd])
                        insert_port_db(temp_ip[asd], temp_port[asd], temp_protocol[asd], temp_portname[asd], temp_state[asd], temp_service[asd], temp_info[asd])
                    else: 
                        if debug_logs == 1:
                            functions.mylog("Port state is %s, for port: %s on %s - not adding - low confidence" % (temp_state[asd], temp_port[asd], temp_ip[asd] ))
                else:
                    #Port exists, so check other fields, log and update as needed
                    cursor.execute('''SELECT rowid, * FROM ports WHERE ip = ? and port = ?''', (temp_ip[asd], temp_port[asd]))
                    check = {}
                    check_protocol = {}
                    check_portname = {}
                    check_state = {}
                    check_service = {}
                    check_info = {}  
                    for row2 in cursor:
                        row_id2 = row2['rowid']
                        check[row_id2] = str(row2['ip'])
                        check_protocol[row_id2] = str(row2['protocol'])
                        check_portname[row_id2] = str(row2['name'])
                        check_state[row_id2] = str(row2['state'])
                        check_service[row_id2] = str(row2['service'])
                        check_info[row_id2] = str(row2['info'])

                    for asd2 in check:
                        test2_protocol = check_protocol[asd2]
                        test2_portname = check_portname[asd2]
                        test2_state = check_state[asd2]
                        test2_service = check_service[asd2]
                        test2_info = check_info[asd2]    

                        # PROTOCOL TESTS
                        if temp_protocol[asd] == test2_protocol:
                            if debug_logs == 1:
                                functions.mylog("Protocols for Port %s match on %s" % (temp_port[asd], temp_ip[asd]))
                        else:
                            functions.mylog("Protocol has changed from %s to %s for Port %s on IP: %s.. Updating" % (test2_protocol, temp_protocol[asd], temp_port[asd], temp_ip[asd]))
                            update_port_record(temp_ip[asd], 'protocol', temp_protocol[asd], temp_port[asd])
                        
                        # PORT NAME  TESTS
                        if temp_portname[asd] == test2_portname:
                            if debug_logs == 1:
                                functions.mylog("Port Name for Port %s match on %s" % (temp_port[asd], temp_ip[asd]))
                        else:
                            functions.mylog("Port Name has changed from %s to %s for Port %s on IP: %s.. Updating" % (test2_portname, temp_portname[asd], temp_port[asd], temp_ip[asd]))
                            update_port_record(temp_ip[asd], 'name', temp_portname[asd], temp_port[asd])
                        
                        # STATE TESTS
                        if temp_state[asd] == test2_state:
                            if debug_logs == 1:
                                functions.mylog("STATE for Port %s match on %s" % (temp_port[asd], temp_ip[asd]))
                        else:
                            functions.mylog("STATE has changed from %s to %s for Port %s on IP: %s.. Updating" % (test2_state, temp_state[asd], temp_port[asd], temp_ip[asd]))
                            update_port_record(temp_ip[asd], 'state', temp_state[asd], temp_port[asd])
                        
                        # SERVICE TESTS
                        if temp_service[asd] == test2_service:
                            if debug_logs == 1:
                                functions.mylog("SERVICE for Port %s match on %s" % (temp_service[asd], temp_ip[asd]))
                        else:
                            functions.mylog("SERVICE has changed from %s to %s for Port %s on IP: %s.. Updating" % (test2_service, temp_service[asd], temp_port[asd], temp_ip[asd]))
                            update_port_record(temp_ip[asd], 'service', temp_service[asd], temp_port[asd])
                        
                        # INFO TESTS
                        if temp_info[asd] == test2_info:
                            if debug_logs == 1:
                                functions.mylog("INFO for Port %s match on %s" % (temp_info[asd], temp_ip[asd]))
                        else:
                            functions.mylog("INFO has changed from %s to %s for Port %s on IP: %s.. Updating" % (test2_info, temp_info[asd], temp_port[asd], temp_ip[asd]))
                            update_port_record(temp_ip[asd], 'info', temp_info[asd], temp_port[asd])
    
    except Exception, e:
        print "%s: exception during insert into table ports\n" % (e)

    cursor.execute('''DELETE FROM temp_ports''')
    db.commit()
    db.close()
if __name__ == "__main__":
    xmlfile = "/opt/system/rdd/%s.xml" % xmlfilename
    main(xmlfile)
    sys.exit(0)

