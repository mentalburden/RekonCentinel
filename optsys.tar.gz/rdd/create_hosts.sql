CREATE TABLE IF NOT EXISTS hosts (
    ip          VARCHAR(16),
    mac         VARCHAR(18),
    hostname    VARCHAR(129),
    protocol    VARCHAR(5) DEFAULT 'ipv4',
    os_name     TEXT,
    os_vendor   TEXT,
    os_family   TEXT,
    os_accuracy INTEGER,
    os_gen      TEXT,
    last_update TIMESTAMP,
    state       VARCHAR(8) DEFAULT 'down',
    mac_vendor  TEXT,
    whois       TEXT,
    authorized  INTEGER,
    sync	INTEGER
);

CREATE TABLE IF NOT EXISTS ports (
    ip          VARCHAR(16) NOT NULL,
    port        INTEGER NOT NULL,
    protocol    VARCHAR(4) NOT NULL,
    name        VARCHAR(33),
    state       VARCHAR(33) DEFAULT 'closed',
    service     TEXT,
    info        TEXT,
    sync	INTEGER
);

CREATE TABLE IF NOT EXISTS temp_ports (
    ip          VARCHAR(16) NOT NULL,
    port        INTEGER NOT NULL,
    protocol    VARCHAR(4) NOT NULL,
    name        VARCHAR(33),
    state       VARCHAR(33) DEFAULT 'closed',
    service     TEXT,
    info        TEXT
);

CREATE TABLE IF NOT EXISTS alert_config (
    rogue_devices          INTEGER DEFAULT 1,
    hostname_change        INTEGER DEFAULT 1,
    protocol_change        INTEGER DEFAULT 0,
    os_name_change         INTEGER DEFAULT 0,
    os_vendor_change       INTEGER DEFAULT 1,
    os_family_change       INTEGER DEFAULT 1,
    os_accuracy_change     INTEGER DEFAULT 0,
    os_gen_change          INTEGER DEFAULT 0,
    state_change           INTEGER DEFAULT 0,
    rogue_ports            INTEGER DEFAULT 1,
    port_protocol_change   INTEGER DEFAULT 1,
    port_name_change       INTEGER DEFAULT 1,
    port_state_change      INTEGER DEFAULT 0,
    port_service_change    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS log_config (
    rogue_devices          INTEGER DEFAULT 1,
    hostname_change        INTEGER DEFAULT 1,
    protocol_change        INTEGER DEFAULT 1,
    os_name_change         INTEGER DEFAULT 0,
    os_vendor_change       INTEGER DEFAULT 1,
    os_family_change       INTEGER DEFAULT 1,
    os_accuracy_change     INTEGER DEFAULT 0,
    os_gen_change          INTEGER DEFAULT 0,
    state_change           INTEGER DEFAULT 1,
    rogue_ports            INTEGER DEFAULT 1,
    port_protocol_change   INTEGER DEFAULT 1,
    port_name_change       INTEGER DEFAULT 1,
    port_state_change      INTEGER DEFAULT 1,
    port_service_change    INTEGER DEFAULT 1
);


CREATE TABLE IF NOT EXISTS app_config (
    normal_scan_interval   INTEGER DEFAULT 1800,
    fast_scan_interncal    INTEGER DEFAULT 300,
    initial_scan           INTEGER
);
INSERT INTO alert_config VALUES (1,1,0,0,1,1,0,0,0,1,1,1,0,0);
INSERT INTO log_config VALUES (1,1,1,0,1,1,0,0,1,1,1,1,1,1);
INSERT INTO app_config VALUES (1800,300,1);
