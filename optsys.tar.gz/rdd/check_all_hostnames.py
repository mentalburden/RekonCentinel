#!/usr/bin/python
## get_avahi_hostname.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# Takes an IP as an argument and returns the hostname
#v 1.1


import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import xml.dom.minidom
import sqlite3
from core import functions
from axonchisel.handoff.object import Ax_Handoff
import requests
from requests.auth import HTTPBasicAuth
from subprocess import call

devnull = open(os.devnull, 'w')

dbfile = "/opt/system/rdd/hosts.db"
#try:
#    ip = sys.argv[1]
##except Exception, e:
#    print "get_avahi_hostname requires an IP address as an argument: %s\n" % (e)
#    sys.exit(0)
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def update_host_record(ip, field, value):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    url = "%s/_update/hostrecord" % (api)
    hostrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"password\": \"%s\"}" % (field, value, deviceid, ip, password)
    api_response = functions.call_post_api(url, hostrecord)
    if api_response == "OK":
        sql_string = "UPDATE hosts SET %s = \"%s\", sync = \"1\" WHERE ip = \'%s\'" % (field, value, ip)
        cursor.execute(sql_string)
        db.commit()
        print "Got OK ACK, Host Record Updated"
    else:
        print "There is an issue with your request: %s" % (api_response)
        sql_string = "UPDATE hosts SET %s = \"%s\", sync = \"0\" WHERE ip = \'%s\'" % (field, value, ip)
        cursor.execute(sql_string)
        db.commit()


ip_list = {}
try:
    ipsql = "SELECT rowid, ip FROM hosts"
    cursor.execute(ipsql)
    for row in cursor:
        row_id = row['rowid']
        ip_list[row_id] = str(row['ip'])
        print row['ip']

except Exception , e:
    print e


for rwid in ip_list:
    ip = ip_list[rwid]

    try:
        call(["/usr/bin/nmap", "-sU", "-p", "137", "--script", "nbstat", ip, "-oX", "/opt/system/rdd/hostnames.xml"], stdout=devnull)

    except Exception, e:
        print e
        sys.exit(0)



    try:
        fname = "/opt/system/rdd/hostnames.xml"
        doc = xml.dom.minidom.parse(fname)
    except IOError:
        print "%s: error: file \"%s\" doesn't exist\n" % (fname, fname)

    except xml.parsers.expat.ExpatError:
        print "%s: error: file \"%s\" doesn't seem to be XML\n" % (fname, fname)

    for host in doc.getElementsByTagName("host"):
        try:
            hostname = "NONE"
            hscript = host.getElementsByTagName("hostscript")[0]
            hscript2 = hscript.getElementsByTagName("script")[0]
            for stuff in hscript2.getElementsByTagName("elem"):
                srv_name = stuff.getAttribute("key")
                if srv_name == "server_name":
                    hostname = stuff.firstChild.data
        except Exception, e:
            hostname = "NONE"
            #print e

    try:
        sql = ("SELECT hostname FROM hosts WHERE ip = \"%s\"") % (ip)
        cursor.execute(sql)
        for row in cursor:
            known_hostname = row['hostname']
    except Exception, e:
        print e


    if hostname == "NONE":
        cmd = "/usr/bin/avahi-resolve-address %s" % (ip)
        raw = functions.cmdline(cmd)
        asd = raw.split()
        try:
            hn1 = asd[1]
            hn = hn1.split('.')
            hostname = hn[0]
            hostname = hostname[:].upper()
            if hostname == known_hostname:
                asd = "Hostname matches, do nothing"
            else:
                sql = "UPDATE hosts SET hostname = \"%s\" WHERE ip = \"%s\"" % (hostname, ip)
                cursor.execute(sql)
                db.commit()
                update_host_record(ip, 'hostname', hostname)
                #This is not a reliable test - so log only
                dalog = "Hostname has changed from %s to %s for %s" % (known_hostname, hostname, ip)
                functions.mylog(dalog)
                #functions.alert("Hostname has changed from %s to %s for %s" % (known_hostname, hostname, ip), '3', ip, 'hostnames')
                db.close()
        except:
            continue
    else:
        try:
            if hostname == known_hostname:
                asd = "Hostname matches, do nothing"
            else:
                sql = "UPDATE hosts SET hostname = \"%s\" WHERE ip = \"%s\"" % (hostname, ip)
                cursor.execute(sql)
                db.commit()
                update_host_record(ip, 'hostname', hostname)
                #This is not a reliable test - so log only
                dalog = "Hostname has changed from %s to %s for %s" % (known_hostname, hostname, ip)
                functions.mylog(dalog)
                #functions.alert("Hostname has changed from %s to %s for %s" % (known_hostname, hostname, ip), '3', ip, 'hostnames')
                db.close()
        except Exception, e:
            print e

