#!/bin/bash
IF=$(/sbin/ifconfig | /bin/grep Ethernet | /usr/bin/awk '{ print $1 }')
/opt/system/scand/scan_daemon.py $IF -d > /dev/null 2>&1

