.output /opt/system/maintenance/cm_dump1.sql
.dump
.exit
