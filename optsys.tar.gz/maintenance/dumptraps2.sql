.output /opt/system/maintenance/traps_dump2.sql
.dump
.exit
