.output /opt/system/maintenance/agent_dump2.sql
.dump
.exit
