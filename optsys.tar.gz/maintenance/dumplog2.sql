.output /opt/system/maintenance/log_dump2.sql
.dump
.exit
