#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import sqlite3
from subprocess import PIPE, Popen
from core import functions

try:
    mode = sys.argv[1]
except Exception, e:
    print "dumpdb.py requires an argument: %s\n" % (e)
    sys.exit(0)



def dump1(dbfile, sqldumpfile):
    try:
        cmd = "/usr/bin/sqlite3 %s < %s" % (dbfile, sqldumpfile)
        functions.cmdline(cmd)
    except Exception as e:
        print "Whoops %s" % e

#dump agent
dbfile = "/opt/system/agent/agent.db"
sqldumpfile = "/opt/system/maintenance/dumpagent%s.sql" % mode
dump1(dbfile, sqldumpfile)

#dump alert
dbfile = "/opt/system/alert/alerts.db"
sqldumpfile = "/opt/system/maintenance/dumpalert%s.sql" % mode
dump1(dbfile, sqldumpfile)

#dump cm
dbfile = "/opt/system/countermeasures/countermeasures.db"
sqldumpfile = "/opt/system/maintenance/dumpcm%s.sql" % mode
dump1(dbfile, sqldumpfile)

#dump log
dbfile = "/opt/system/log/log.db"
sqldumpfile = "/opt/system/maintenance/dumplog%s.sql" % mode
dump1(dbfile, sqldumpfile)

#dump rdd
dbfile = "/opt/system/rdd/hosts.db"
sqldumpfile = "/opt/system/maintenance/dumprdd%s.sql" % mode
dump1(dbfile, sqldumpfile)

#dump traps
dbfile = "/opt/system/traps/traps.db"
sqldumpfile = "/opt/system/maintenance/dumptraps%s.sql" % mode
dump1(dbfile, sqldumpfile)
