#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import sqlite3
from subprocess import PIPE, Popen
from core import functions

def checkonedb(dbfile):
    try:
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
        sql = "SELECT name FROM sqlite_master WHERE type='table'"
        cursor.execute(sql)
        return True
    except Exception as e:
        return False

def repairdb(dbfile, sqldumpfile):
    try:
        sqldumpfile1 = "/opt/system/maintenance/%s1.sql" % sqldumpfile
        cmd = "/bin/rm -rf %s" % dbfile
        asd = functions.cmdline(cmd)
        cmd = "/usr/bin/sqlite3 %s < %s" % (dbfile, sqldumpfile1)
        test1 = checkonedb(dbfile)
        if test1 is True:
            maintlog = "Database %s has been successfully repaired" % dbfile
            functions.mylog(maintlog)
            return True
        else:
            maintlog = "Database %s repair failed, trying second attempt..." % dbfile
            functions.mylog(maintlog)
            sqldumpfile2 = "/opt/system/maintenance/%s2.sql" % sqldumpfile
            cmd = "/bin/rm -rf %s" % dbfile
            asd = functions.cmdline(cmd)
            cmd = "/usr/bin/sqlite3 %s < %s" % (dbfile, sqldumpfile2)
    except Exception as e:
        return False

#dump agent
dbfile = "/opt/system/agent/agent.db"
sqldumpfile = "dumpagent"
dbtest = checkonedb(dbfile)
if dbtest is False:
    maintlog = "Agent Database is damaged..reparing"
    functions.mylog(maintlog)
    repair_successful = repairdb(dbfile, sqldumpfile)
else:
    maintlog = "Agent Database is OK"
    functions.mylog(maintlog)

#dump alert
dbfile = "/opt/system/alert/alerts.db"
sqldumpfile = "dumpalert"
dbtest = checkonedb(dbfile)
if dbtest is False:
    maintlog = "Alert Database is damaged..reparing"
    functions.mylog(maintlog)
    repair_successful = repairdb(dbfile, sqldumpfile)
else:
    maintlog = "Alert Database is OK"
    functions.mylog(maintlog)

#dump cm
dbfile = "/opt/system/countermeasures/countermeasures.db"
sqldumpfile = "dumpcm"
dbtest = checkonedb(dbfile)
if dbtest is False:
    maintlog = "Countermeasures Database is damaged..reparing"
    functions.mylog(maintlog)
    repair_successful = repairdb(dbfile, sqldumpfile)
else:
    maintlog = "Countermeasures Database is OK"
    functions.mylog(maintlog)

#dump log
dbfile = "/opt/system/log/log.db"
sqldumpfile = "dumplog" 
dbtest = checkonedb(dbfile)
if dbtest is False:
    maintlog = "Log Database is damaged..reparing"
    functions.mylog(maintlog)
    repair_successful = repairdb(dbfile, sqldumpfile)
else:
    maintlog = "Log Database is OK"
    functions.mylog(maintlog)

#dump rdd
dbfile = "/opt/system/rdd/hosts.db"
sqldumpfile = "dumprdd" 
dbtest = checkonedb(dbfile)
if dbtest is False:
    maintlog = "Host Database is damaged..reparing"
    functions.mylog(maintlog)
    repair_successful = repairdb(dbfile, sqldumpfile)
else:
    maintlog = "Host Database is OK"
    functions.mylog(maintlog)

#dump traps
dbfile = "/opt/system/traps/traps.db"
sqldumpfile = "dumptraps"
dbtest = checkonedb(dbfile)
if dbtest is False:
    maintlog = "Traps Database is damaged..reparing"
    functions.mylog(maintlog)
    repair_successful = repairdb(dbfile, sqldumpfile)
else:
    maintlog = "Traps Database is OK"
    functions.mylog(maintlog)
