.output /opt/system/maintenance/cm_dump2.sql
.dump
.exit
