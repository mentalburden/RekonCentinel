PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE agent_config (
    deviceid        TEXT,
    password        TEXT,
    shared_secret   TEXT,
    preregistered   INTEGER default 0,
    registered      INTEGER default 0,
    hash            TEXT
);
INSERT INTO "agent_config" VALUES('1cNfFpYdPwBh','aJdn6Do9yGNC3xc4tfgRDxcn5wBylOztTPEqgvNegoVRVLjrNx','D5M8bZDhw9FMMGT3Vycgtis5Y21pBAXFhI1IZW1iau4G4jEdscsWEjH7s1DqHHel6Yngaikn4f4C2LoSCjnxmPBJnYtwHU1z1tvvnqQiZtjvFxZTbwEpgSTLYbK5Pyr2fiBuhd7X7HJiUYmSxJonJ0gqSV5O3HAwmhvQv3hjNulWrBvv04GADOFfJFvMkNOMfrs2Fv1B8ePcMOmMZLzjcqKtpJydJiYs3dWykfZHaTy9VKHuoyb9CrBjb7',1,0,'$2a$12$PiZRYWFB71BljHXgTlFPYOMVYn6YGzhBYKe8j6fxKd6wO5GFsDfh.');
COMMIT;
