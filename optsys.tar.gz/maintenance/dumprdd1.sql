.output /opt/system/maintenance/hosts_dump1.sql
.dump
.exit
