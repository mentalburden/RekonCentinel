PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE countermeasures (
    target_ip       VARCHAR(32),
    active          INTEGER
);
COMMIT;
