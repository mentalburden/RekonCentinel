.output /opt/system/maintenance/hosts_dump2.sql
.dump
.exit
