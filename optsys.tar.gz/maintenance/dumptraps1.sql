.output /opt/system/maintenance/traps_dump1.sql
.dump
.exit
