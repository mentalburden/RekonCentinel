.output /opt/system/maintenance/alert_dump1.sql
.dump
.exit
