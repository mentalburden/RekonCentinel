.output /opt/system/maintenance/agent_dump1.sql
.dump
.exit
