.output /opt/system/maintenance/alert_dump2.sql
.dump
.exit
