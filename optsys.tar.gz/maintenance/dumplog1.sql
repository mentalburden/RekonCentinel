.output /opt/system/maintenance/log_dump1.sql
.dump
.exit
