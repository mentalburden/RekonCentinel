PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE alerts (
    alert_time	TIMESTAMP,
    hostname    VARCHAR(129),
    message     TEXT,
    severity	INTEGER,
    ack		INTEGER,
    notified    INTEGER,
    ip          VARCHAR(16),
    alert_type        VARCHAR(129),
    sync        INTEGER
);
COMMIT;
