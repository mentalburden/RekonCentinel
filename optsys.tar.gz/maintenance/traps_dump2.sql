PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE traps (
    name            VARCHAR(129),
    description     TEXT,
    port            INTEGER,
    active          INTEGER
);
INSERT INTO "traps" VALUES('http','Configuration for Web enabled Devices',80,0);
INSERT INTO "traps" VALUES('https','Secure Configuration for Web enabled Devices',443,0);
INSERT INTO "traps" VALUES('httpconfig','Commonly used configuration port for web enabled IoT Devices',8080,0);
INSERT INTO "traps" VALUES('rdp','Remote Desktop Protocol - commonly used for remote access',3389,0);
INSERT INTO "traps" VALUES('telnet','Telnet - Commonly used command line remote access ',23,0);
INSERT INTO "traps" VALUES('mogodb','Mongo Database - Commonly used database for IoT Devices',27017,0);
INSERT INTO "traps" VALUES('mysqlsql','MySQL - Commonly used SQL database',3306,0);
INSERT INTO "traps" VALUES('postgresql','PostgreSQL - Commonly used SQL database',5432,0);
INSERT INTO "traps" VALUES('mssql','Microsoft SQL Server - Commonly used SQL database',1433,0);
INSERT INTO "traps" VALUES('sip','Session Initiated Protocol - Commonly used for VOIP devices',5060,0);
INSERT INTO "traps" VALUES('smtp','Simple Mail Transfer Protocol - Used for email servers',25,0);
INSERT INTO "traps" VALUES('netbios','NetBIOS - Used for file sharing in Windows',139,0);
INSERT INTO "traps" VALUES('smb','Server Message Block - Used for file sharing in Windows',445,0);
INSERT INTO "traps" VALUES('rpc','Remote Procedure Call - Used for sharing services in Windows',135,0);
INSERT INTO "traps" VALUES('print','RAW Print Protocol - Used by network printers',9100,0);
INSERT INTO "traps" VALUES('iPhone','iPhone Sync - Used by iPhones',62078,0);
COMMIT;
