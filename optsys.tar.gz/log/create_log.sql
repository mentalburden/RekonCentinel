CREATE TABLE IF NOT EXISTS log (
    log_time	TIMESTAMP,
    hostname    VARCHAR(129),
    message     TEXT,
    sync	INTEGER
);
