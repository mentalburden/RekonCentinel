#!/usr/bin/python

#secret agent man 


from axonchisel.handoff.object import Ax_Handoff
import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import time
import getopt
import sqlite3
from core import functions
from pbkdf2 import crypt
import bcrypt
import requests
import json
import daemon
from requests.auth import HTTPBasicAuth
from subprocess import call

dbfile = "/opt/system/agent/agent.db"
firmware_version = "1.21.43"
version = "VERSION "
version += firmware_version


try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)


try:
    sql = "SELECT * FROM agent_config"
    cursor.execute(sql)
    for row in cursor:
        deviceid = row['deviceid']
        password = row['password']
        sharedsecret = row['shared_secret']
except Exception as e:
    print "agent_config: %s\n" % e

def get_command():
    data1 = "{\"deviceid\": \"%s\", \"password\": \"%s\", \"ask\": \"getcmd\"}" % (deviceid, password)
    encdata = Ax_Handoff.encode(data1, sharedsecret)
    api = functions.get_apiurl()
    url = "%s/_cmd/%s" % (api, encdata)
    headers = {}
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password), timeout=30)
    json_data = Ax_Handoff.decode(res.text, sharedsecret)
    return json_data

def check_authorized():
    cmd = "{\"cmd\": \"checkauth\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    encdata = Ax_Handoff.encode(cmd, sharedsecret)
    api = functions.get_apiurl()
    url = "%s/_check/%s" % (api, encdata)
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password), timeout=30)
    auth_status = Ax_Handoff.decode(res.text, sharedsecret)
    return auth_status

def update_authorized_hosts(ip, mac, authorized):
    hostsdb = "/opt/system/rdd/hosts.db"
    try:
        dbconn = sqlite3.connect(hostsdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
        sql = "UPDATE hosts SET authorized = \"%s\" WHERE ip = \"%s\" AND mac = \"%s\"" % (authorized, ip, mac)
        c.execute(sql)
        dbconn.commit()
        if authorized == "0":
            #sql = "DELETE FROM hosts WHERE ip = \"%s\"" % (ip)
            sql = "UPDATE hosts set authorized = 0 WHERE ip = \"%s\" AND mac = \"%s\"" % (ip, mac)
            c.execute(sql)
            dbconn.commit()
            functions.alert("Rogue Device Detected!!! IP: %s" % (ip), '1', ip, 'rogue')
            #sql = "DELETE FROM ports WHERE ip = \"%s\"" % (ip)
            #c.execute(sql)
            #dbconn.commit()
        dbconn.close()
        return "OK"
    
    except Exception as e:
        return e
    return "OK"

def authorize_all_hosts():
    hostsdb = "/opt/system/rdd/hosts.db"
    try:
        dbconn = sqlite3.connect(hostsdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
        sql = "UPDATE hosts SET authorized = \"1\" WHERE authorized = \"0\""
        c.execute(sql)
        dbconn.commit()
        dbconn.close()
        return "OK"
    except Exception as e:
        return e
    return "OK"

def deauthorize_all_hosts():
    hostsdb = "/opt/system/rdd/hosts.db"
    try:
        dbconn = sqlite3.connect(hostsdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
        sql = "UPDATE hosts SET authorized = \"0\" WHERE authorized = \"1\""
        c.execute(sql)
        dbconn.commit()
        dbconn.close()
        return "OK"
    except Exception as e:
        return e
    return "OK"


def delete_host(ip, mac):
    hostsdb = "/opt/system/rdd/hosts.db"
    try:
        dbconn = sqlite3.connect(hostsdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
    
        sql = "DELETE FROM hosts WHERE ip = \"%s\" AND mac = \"%s\"" % (ip, mac)
        c.execute(sql)
        dbconn.commit()
        sql = "DELETE FROM ports WHERE ip = \"%s\"" % (ip)
        c.execute(sql)
        dbconn.commit()
        dbconn.close()
        return "OK"
    
    except Exception as e:
        return e
    return "OK"

def update_traps(port, active):
    trapsdb = "/opt/system/traps/traps.db"
    try:
        dbconn = sqlite3.connect(trapsdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
    
        sql = "UPDATE traps SET active = \"%s\" WHERE port = \"%s\"" % (active, port)
        c.execute(sql)
        dbconn.commit()
        dbconn.close()
        return "OK"
    
    except Exception as e:
        return e
    return "OK"

def update_countermeasures(target_ip, active):
    cmdb = "/opt/system/countermeasures/countermeasures.db"
    try:
        dbconn = sqlite3.connect(cmdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
        sql = "SELECT * FROM countermeasures WHERE target_ip = \"%s\"" % (target_ip)
        c.execute(sql)
        rows = c.fetchall()
        if rows:
            sql = "UPDATE countermeasures SET active = \"%s\" WHERE target_ip = \"%s\"" % (active, target_ip)
            c.execute(sql)
            dbconn.commit()
        else:
            sql = "INSERT INTO countermeasures (target_ip, active) VALUES (\"%s\",\"%s\")" % (target_ip, active)
            c.execute(sql)
            dbconn.commit()
        dbconn.close()
        return "OK"
    
    except Exception as e:
        return e
    return "OK"

def stop_countermeasures():
    cmdb = "/opt/system/countermeasures/countermeasures.db"
    try:
        dbconn = sqlite3.connect(cmdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
        sql = "UPDATE countermeasures SET active = 0"
        c.execute(sql)
        dbconn.commit()
        dbconn.close()
        return "OK"
    
    except Exception as e:
        return e
    return "OK"


def clear_all_countermeasures():
    cmdb = "/opt/system/countermeasures/countermeasures.db"
    try:
        dbconn = sqlite3.connect(cmdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
        sql = "DELETE FROM countermeasures"
        c.execute(sql)
        dbconn.commit()
        dbconn.close()
        return "OK"
    
    except Exception as e:
        return e
    return "OK"


def stop_traps():
    trapsdb = "/opt/system/traps/traps.db"
    try:
        dbconn = sqlite3.connect(trapsdb)
        dbconn.row_factory = sqlite3.Row
        c = dbconn.cursor()
    
        sql = "UPDATE traps SET active = 0"
        c.execute(sql)
        dbconn.commit()
        dbconn.close()
        return "OK"
    
    except Exception as e:
        return e
    return "OK"

def register(cmd_id):
    api = functions.get_apiurl()
    url = "%s/_init/register" % (api)
    data = "{\"deviceid\": \"%s\", \"cmd_id\": \"%s\", \"password\": \"%s\"}" % (deviceid, cmd_id, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        sql = "UPDATE agent_config SET registered = 1 WHERE deviceid = \"%s\"" % (deviceid)
        cursor.execute(sql)
        db.commit()
        return True

def getandrunscript(url, script):
    scriptpath = "/opt/system/agent/%s" % (script)
    with open(scriptpath, 'wb') as handle:
        res = requests.get(url, auth=HTTPBasicAuth(deviceid, password), stream=True, timeout=30)
        if not res.ok:
            return res.text
        for block in res.iter_content(1024):
            handle.write(block)
        handle.close()
    ick = "/bin/chmod +x %s" % (scriptpath)
    icky = functions.cmdline(ick)
    status = functions.cmdline(scriptpath)
    return status.rstrip()

def ack_cmd(cmd_id):
    api = functions.get_apiurl()
    url = "%s/_agent/script/ack" % (api)
    data = "{\"cmd_id\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (cmd_id, deviceid, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        #print "Got OK ACK, Command Complete"
        return True
    else:
        print "There is an issue with command id: %s : %s" % (cmd_id, api_response)
        return False

def set_systemstatus(status):
    ts = time.time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
    api = functions.get_apiurl()
    url = "%s/_status/system" % (api)
    data = "{\"status\": \"%s\", \"timestamp\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (status, timestamp, deviceid, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False
 
def alert_check():
    authed = check_authorized()
    if authed == "AUTHORIZED":
        api = functions.get_apiurl()
        url = "%s/_check/alerts" % (api)
        data = "{\"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
        api_response = functions.call_post_api(url, data)
        if api_response == "OK":
            return True
        else:
            return False
    else:
        return False
    
def factory_reset():
    api = functions.get_apiurl()
    url = "%s/_init/factoryreset" % (api)        
    data = "{\"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False

def clearstatus():
    api = functions.get_apiurl()
    url = "%s/_init/clearstatus" % (api)        
    data = "{\"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False

def clearalerts():
    api = functions.get_apiurl()
    url = "%s/_init/clearalerts" % (api)        
    data = "{\"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False

def setupcomplete():
    api = functions.get_apiurl()
    url = "%s/_init/setupcomplete" % (api)
    data = "{\"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False

def set_lcd_status(lcd_status):
    if lcd_status == 0:
        lcd_status = 1
    elif lcd_status == 1:
        lcd_status = 0
    api = functions.get_apiurl()
    url = "%s/_update/lcd_status" % (api)        
    data = "{\"deviceid\": \"%s\", \"password\": \"%s\", \"lcd_status\": \"%s\"}" % (deviceid, password, lcd_status)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False

def set_firmware_version(firmware_version):
    api = functions.get_apiurl()
    url = "%s/_update/firmware_version" % (api)        
    data = "{\"deviceid\": \"%s\", \"password\": \"%s\", \"firmware_version\": \"%s\"}" % (deviceid, password, firmware_version)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False

def sysupdate():
    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep unattended-upgrade | /usr/bin/awk '{print $2}'"
    uu_pid = functions.cmdline(cmd)
    uu_pid = str(uu_pid.rstrip())
    if uu_pid:
        asd = "Do nothing"
        return False
    else:
        cmd2 = "/bin/ps aux | /bin/grep -v grep | /bin/grep sysupdate.sh | /usr/bin/awk '{print $2}'"
        su_pid = functions.cmdline(cmd2)
        su_pid = str(su_pid.rstrip())
        if su_pid:
            asd = "do nothing"
            return False
        else:
            sysupdate_file = os.path.isfile("/opt/system/sysupdates/sysupdate.sh")
            if sysupdate_file:
                cmd = "/opt/system/sysupdates/sysupdate.sh"
                functions.cmdline(cmd)
            return True

def get_display_alert_status():
    api = functions.get_apiurl()
    url = "%s/_check/display" % (api)
    data = "{\"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    api_response = functions.call_post_api(url, data)
    return api_response

def display_deviceid(id_disp, lcd_off):
    if id_disp == 1:
        asd = "id already displayed"
        return 1
    elif not lcd_off:
        line2 = str(deviceid)
        line2 = line2.rstrip()
        asd = functions.display_lcd("DEVICE ID:", line2)
        return 1

def display_standing_guard(lcd_off):
    if not lcd_off:
        line1 = "Recon Sentinel"
        line2 = "Standing Guard"
        asd = functions.display_lcd(line1, line2)
        return 1

def start_sonar(ip):
    #check if sonar is running:
    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep sonar.py | /bin/grep python | /usr/bin/awk '{print $2}'"
    sonar_run = functions.cmdline(cmd)
    sonar_run = str(sonar_run.rstrip())
    if sonar_run:
        asd = functions.display_lcd("SONAR IS", "ALREADY RUNNING")
        cmd = "/opt/system/sonar/stop_sonar.py"
        asd = functions.cmdline(cmd)
    else:
        cmd = "/opt/system/sonar/sonar.py %s" % (ip)
        asd = functions.cmdline(cmd)

def stop_sonar():
    cmd = "/opt/system/sonar/stop_sonar.py"
    asd = functions.cmdline(cmd)
    
def runagent():
    asd = functions.display_lcd("RECON SENTINEL", version)
    poll = 1
    display_trk = 0
    first_run = 1
    issue = 0
    id_disp = 0
    lcd_off = 0
    registering = 0
    cmd = "/usr/sbin/service ssh restart"
    asd = functions.cmdline(cmd)
    cstat = clearstatus()
    system_status = "OK"
    asd = functions.set_systemstatus(system_status, "1")
    cmd = "/opt/system/maintenance/dbcheck.py"
    functions.cmdline(cmd)
    comm_error = 0
    asd = set_firmware_version(firmware_version)
    id_disp = display_standing_guard(lcd_off)

    try:
        while True:
            try:
                if not display_trk:
                    firmw = functions.cmdline("/opt/system/agent/update_firmware.py")
                    sysup = functions.cmdline("/opt/system/agent/system_updates.py")
                    try:
                        asd = sysupdate()
                    except:
                        continue

                set_lcd_status(lcd_off)
                command = get_command()
                resp = json.loads(command)
                authed = check_authorized()
                if authed == "AUTHORIZED":
                    asd = alert_check()
                    if comm_error > 0:
                        comm_error = 0
                        if not lcd_off:
                            id_disp = 0
                            #id_disp = display_deviceid(id_disp, lcd_off)
                            id_disp = display_standing_guard(lcd_off)
                    if first_run:
                        try:
                            dbtfile = "/opt/system/log/log.db"
                            dbt = sqlite3.connect(dbtfile)
                            dbt.row_factory = sqlite3.Row
                            cursort = dbt.cursor()
                        except:
                            continue
                        sql = "VACUUM"
                        cursort.execute(sql)
                        dbt.close()

                        try:
                            dbtfile = "/opt/system/alert/alerts.db"
                            dbt = sqlite3.connect(dbtfile)
                            dbt.row_factory = sqlite3.Row
                            cursort = dbt.cursor()
                        except:
                            continue
                        sql = "VACUUM"
                        cursort.execute(sql)
                        dbt.close()
                        #if not lcd_off:
                            #id_disp = display_deviceid(id_disp, lcd_off)
                            #id_disp = display_standing_guard(lcd_off)
                    system_status = "OK"
                    td = functions.cmdline("/opt/system/traps/trap_daemon.py")
                    #cd = functions.cmdline("/opt/system/countermeasures/cm_daemon.py")
                    cmd = "/sbin/ifconfig eth0 | /bin/grep PROMISC"
                    promisc = functions.cmdline(cmd)
                    if promisc:
                        asd = "naughty girl"
                    else:
                        #print "tsk - not in promiscuous mode.. shame"
                        cmd = "/sbin/ifconfig eth0 promisc"
                        asd = functions.cmdline(cmd)
                        system_status = "Network Not In Correct Mode"
                        #asd = set_systemstatus(system_status)
                        functions.mylog(system_status)

                    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep rdd_daemon | /bin/grep python | /usr/bin/awk '{print $2}'"
                    rdd_pid = functions.cmdline(cmd)
                    rdd_pid = str(rdd_pid.rstrip())
                    if rdd_pid:
                        #print "rdd running %s - OK" % (rdd_pid)
                        asd = "just here in case"
                    else:
                        #print "rdd not running - starting"
                        cmd = "/opt/system/rdd/rdd_daemon.py"
                        asd = functions.cmdline(cmd)
                        if first_run:
                            system_status = "Reboot Successful, Starting Rogue Device Detection..."
                            #asd = set_systemstatus(system_status)
                            functions.mylog(system_status)
                        else:
                            system_status = "Rogue Device Detection Not Running"
                            #asd = set_systemstatus(system_status)
                            functions.mylog(system_status)

                    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep scan_daemon | /usr/bin/awk '{print $2}'"
                    sd_pid = functions.cmdline(cmd)
                    sd_pid = str(sd_pid.rstrip())
                    if sd_pid:
                        asd = "just here in case"
                        #print "scan daemon running %s - OK" % (sd_pid)
                    else:
                        #print "scand not running - starting"
                        cmd = "/opt/system/scand/scan_daemon.sh"
                        asd = functions.cmdline(cmd)
                        if first_run:
                            system_status = "Starting Network Scan Detection..."
                            #asd = set_systemstatus(system_status)
                            functions.mylog(system_status)
                        else:
                            system_status = "Network Scan Detection Not Running"
                            #asd = set_systemstatus(system_status)
                            functions.mylog(system_status)
                    if first_run: 
                            system_status = "Reboot Complete."
                            #asd = set_systemstatus(system_status)
                            functions.mylog(system_status)
                            first_run = 0
                    if system_status == "OK":
                        asd = functions.set_systemstatus(system_status, "1")

                    display_alert = get_display_alert_status()

                    if display_alert == "ISSUE":
                        if issue == 0:
                            line1 = "RECON SENTINEL"
                            line2 = "ISSUE DETECTED!"
                            asd = functions.display_lcd(line1,line2)
                            id_disp = 0
                            issue = 1
                            lcd_off = 0
                    elif display_alert == "ROGUESERVICE":
                        if issue == 0:
                            line1 = "NEW NETWORK"
                            line2 = "SERVICE DETECTED"
                            asd = functions.display_lcd(line1,line2)
                            id_disp = 0
                            issue = 1
                            lcd_off = 0
                    else:
                        if not registering:
                            #id_disp = display_deviceid(id_disp, lcd_off)
                            id_disp = display_standing_guard(lcd_off)
                        issue = 0

                else:
                    #firmw = functions.cmdline("/opt/system/agent/update_firmware.py")
                    #sysup = functions.cmdline("/opt/system/agent/system_updates.py")
                    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep rdd_daemon | /bin/grep python | /usr/bin/awk '{print $2}'"
                    rdd_pid = functions.cmdline(cmd)
                    rdd_pid= str(rdd_pid.rstrip())
                    if rdd_pid:
                        #print "rdd running %s - STOPPING" % (rdd_pid)
                        cmd = "/bin/kill -9 %s" % (rdd_pid)
                        asd = functions.cmdline(cmd)
                    else:
                        #print "rdd not running - OK"
                        asd = "just here in case"

                    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep scan_daemon | /bin/grep python | /usr/bin/awk '{print $2}'"
                    sd_pid = functions.cmdline(cmd)
                    sd_pid= str(sd_pid.rstrip())
                    if sd_pid:
                        #print "scan daemon running %s - STOPPING" % (sd_pid)
                        cmd = "/bin/kill -9 %s" % (sd_pid)
                        asd = functions.cmdline(cmd)
                    else:
                        #print "scand not running OK"
                        asd = "just here in case"
                    asd = stop_countermeasures() 
                    asd = stop_traps()
                    cd = functions.cmdline("/opt/system/countermeasures/cm_daemon.py")
                    td = functions.cmdline("/opt/system/traps/trap_daemon.py")
                    id_disp = display_deviceid(0, 0)

                #check if there are commands to run
                if resp['cmd'] != "none":
                    poll = 0
                    if resp['cmd'] == "register":
                        line1 = "REGISTERING"
                        line2 = "RECON SENTINEL"
                        asd = functions.display_lcd(line1,line2)
                        asd = functions.set_systemstatus("Registering Recon Sentinel....", "5")
                        check_reg = register(resp['cmd_id'])
                        lcd_off = 0
                        registering = 1
    
                    elif resp['cmd'] == "getscript":
                        surl = "%s/%s" % (resp['scripturl'], resp['script'])
                        script_status = getandrunscript(surl, resp['script'])
                        if script_status == "OK":
                            ack_status = ack_cmd(resp['cmd_id'])
                        else:
                            print "Issue with script %s" % (script_status)

                    elif resp['cmd'] == "factoryreset":
                        ack_status = ack_cmd(resp['cmd_id'])
                        line1 = "RECON SENTINEL"
                        line2 = "FACTORY RESET"
                        asd = functions.display_lcd(line1,line2)
                        asd = functions.set_systemstatus("Resetting Recon Sentinel to factory defaults....", "6")
                        asd = functions.cmdline("/bin/rm -f /opt/system/log/log.txt")
                        asd = functions.cmdline("/bin/rm -f /opt/system/log/log.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/log/log.db < /opt/system/log/create_log.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/alert/alert.txt")
                        asd = functions.cmdline("/bin/rm -f /opt/system/alert/alerts.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/alert/alerts.db < /opt/system/alert/create_alert.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/rdd/hosts.db")
                        asd = functions.cmdline("/bin/rm -f /opt/system/rdd/*.xml")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/rdd/hosts.db < /opt/system/rdd/create_hosts.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/traps/traps.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/create_traps.sql")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/initial_traps.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/countermeasures/countermeasures.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/countermeasures/countermeasures.db < /opt/system/countermeasures/create_countermeasures.sql")
                        asd = functions.set_systemstatus("Updating Server..........", "6")
                        fr = factory_reset()
                        if fr == True:
                            #cstat = clearstatus()
                            calert = clearalerts()
                            asd = functions.set_systemstatus("Factory Default Settings Complete.", "1")
                            line1 = "COMPLETE"
                            line2 = ""
                            asd = functions.display_lcd(line1,line2)
                            td = functions.cmdline("/sbin/reboot")
                        else:
                            line1 = "ERROR"
                            line2 = "Contact Support"
                            asd = functions.display_lcd(line1,line2)
                            asd = functions.set_systemstatus("There was in issue updating the server, please contact support.", "6")
 
                        lcd_off = 0
    
                    elif resp['cmd'] == "initscan":
                        lcd_off = 0
                        asd = functions.set_systemstatus("Preparing Recon Sentinel for first use....", "5")
                        line1 = "PREPARING"
                        line2 = "FIRST USE"
                        asd = functions.display_lcd(line1,line2)
                        asd = functions.cmdline("/bin/rm -f /opt/system/log/log.txt")
                        asd = functions.cmdline("/bin/rm -f /opt/system/log/log.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/log/log.db < /opt/system/log/create_log.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/alert/alert.txt")
                        asd = functions.cmdline("/bin/rm -f /opt/system/alert/alerts.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/alert/alerts.db < /opt/system/alert/create_alert.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/rdd/hosts.db")
                        asd = functions.cmdline("/bin/rm -f /opt/system/rdd/*.xml")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/rdd/hosts.db < /opt/system/rdd/create_hosts.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/traps/traps.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/create_traps.sql")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/initial_traps.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/countermeasures/countermeasures.db")
                        asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/countermeasures/countermeasures.db < /opt/system/countermeasures/create_countermeasures.sql")
                        asd = functions.cmdline("/bin/rm -f /opt/system/maintenance/*.sql")
                        cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep rdd_daemon | /bin/grep python | /usr/bin/awk '{print $2}'"
                        rdd_pid = functions.cmdline(cmd)
                        rdd_pid= str(rdd_pid.rstrip())
                        if rdd_pid:
                            #print "rdd running %s - STOPPING" % (rdd_pid)
                            cmd = "/bin/kill -9 %s" % (rdd_pid)
                            asd = functions.cmdline(cmd)
                        else:
                            #print "rdd not running - OK"
                            asd = "just here in case"

                        asd = functions.set_systemstatus("Doing a fast network inventory....", "5")
                        line1 = "INITIAL"
                        line2 = "INVENTORY"
                        asd = functions.display_lcd(line1,line2)
                        call(["/opt/system/rdd/recon_alpha.py", "fast"])
                        asd = functions.set_systemstatus("Complete....", "5")
                        asd = functions.set_systemstatus("Reviewing Inventory Data...", "5")
                        line1 = "REVIEWING"
                        line2 = "DATA"
                        asd = functions.display_lcd(line1,line2)
                        call(["/opt/system/rdd/recon_bravo.py", "initial", "fast_inventory"])
                        asd = functions.set_systemstatus("Complete....", "5")
                        asd = functions.set_systemstatus("Performing Intense probe on found devices...", "5")
                        results = functions.cmdline("/opt/system/rdd/recon_charlie.py initial")
                        #asd = functions.set_systemstatus("Cleaning up....", "5")
                        #asd = functions.set_systemstatus("Setting up Cyber Deception Traps....", "5")
                        ack_status = ack_cmd(resp['cmd_id'])
                        results = functions.cmdline("/opt/system/alert/ack_initial_alerts.py")
                        cstat = clearalerts()
                        #asd = functions.send_status("SUCCESS!")
                        asd = functions.set_systemstatus("OK", "1")
                        #cstat = clearstatus()
                        #asd = set_systemstatus("OK")
                        line1 = "SCANNING"
                        line2 = "COMPLETE"
                        id_disp = 0
                        asd = functions.display_lcd(line1,line2)
                        #id_disp = display_deviceid(id_disp, 0)
                        id_disp = display_standing_guard(0)
                        asd = setupcomplete()
                        registering = 0
    
                    elif resp['cmd'] == "get_authorized_host":
                        ip = resp['ip']
                        mac = resp['mac']
                        authorized = str(resp['authorized'])
                        asd = update_authorized_hosts(ip, mac, authorized)
                        if asd == "OK":
                            ack_status = ack_cmd(resp['cmd_id'])
                        else:
                            print "Issue with update_authorized_hosts %s" % (asd)

                    elif resp['cmd'] == "trust_all_hosts":
                        ack_status = ack_cmd(resp['cmd_id'])
                        system_status = "Trusting All Hosts"
                        asd = functions.set_systemstatus(system_status, "8")
                        asd = authorize_all_hosts()
                        if asd == "OK":
                            system_status = "OK"
                            asd = functions.set_systemstatus(system_status, "1")
                        else:
                            system_status = "ERROR"
                            asd = functions.set_systemstatus(system_status, "8")

                    elif resp['cmd'] == "untrust_all_hosts":
                        ack_status = ack_cmd(resp['cmd_id'])
                        system_status = "Untrusting All Hosts"
                        asd = functions.set_systemstatus(system_status, "9")
                        asd = deauthorize_all_hosts()
                        if asd == "OK":
                            system_status = "OK"
                            asd = functions.set_systemstatus(system_status, "1")
                        else:
                            system_status = "ERROR"
                            asd = functions.set_systemstatus(system_status, "9")
 
                    elif resp['cmd'] == "delete_host":
                        ip = resp['ip']
                        mac = resp['mac']
                        asd = delete_host(ip, mac)
                        if asd == "OK":
                            ack_status = ack_cmd(resp['cmd_id'])
                        else:
                            print "Issue with delete_host %s" % (asd)
   
                    elif resp['cmd'] == "update_traps":
                        port = resp['port']
                        active = resp['active']
                        asd = update_traps(port, active)
                        if asd == "OK":
                            ack_status = ack_cmd(resp['cmd_id'])
                            td = functions.cmdline("/opt/system/traps/trap_daemon.py")
                        else:
                            print "Issue with script %s" % (asd)

                    elif resp['cmd'] == "update_countermeasures":
                        targetip = resp['target_ip']
                        active = resp['active']
                        asd = update_countermeasures(targetip, active)
                        if asd == "OK":
                            ack_status = ack_cmd(resp['cmd_id'])
                            td = functions.cmdline("/opt/system/countermeasures/cm_daemon.py")
                        else:
                            print "Issue with script %s" % (asd)

                    elif resp['cmd'] == "clear_all_countermeasures":
                        asd = clear_all_countermeasures()
                        if asd == "OK":
                            ack_status = ack_cmd(resp['cmd_id'])
                        else:
                            print "Issue with script %s" % (asd)


                    elif resp['cmd'] == "reboot":
                        lcd_off = 0
                        ack_status = ack_cmd(resp['cmd_id'])
                        system_status = "Rebooting System"
                        asd = functions.set_systemstatus(system_status, "3")
                        line1 = "RECON SENTINEL"
                        line2 = "REBOOTING"
                        asd = functions.display_lcd(line1,line2)
                        td = functions.cmdline("/sbin/reboot")
 
                    elif resp['cmd'] == "halt":
                        lcd_off = 0
                        ack_status = ack_cmd(resp['cmd_id'])
                        system_status = "System Halted"
                        asd = functions.set_systemstatus(system_status, "4")
                        line1 = "RECON SENTINEL"
                        line2 = "POWERING OFF"
                        asd = functions.display_lcd(line1,line2)
                        asd = functions.set_systemstatus("System Halted", "2")
                        td = functions.cmdline("/sbin/poweroff")

                    elif resp['cmd'] == "debug":
                        lcd_off = 0
                        line1 = "RECON SENTINEL"
                        line2 = "DEBUG MODE"
                        asd = functions.display_lcd(line1,line2)
                        cmd = "/usr/sbin/service ssh restart"
                        asd = functions.cmdline(cmd)
                        ack_status = ack_cmd(resp['cmd_id'])

                    elif resp['cmd'] == "sysupdate":
                        ack_status = ack_cmd(resp['cmd_id'])
                        lcd_off = 0
                        line1 = "RECON SENTINEL"
                        line2 = "SYSTEM UPDATE"
                        asd = functions.display_lcd(line1,line2)
                        asd = sysupdate()

                    elif resp['cmd'] == "start_sonar":
                        ack_status = ack_cmd(resp['cmd_id'])
                        lcd_off = 0
                        line1 = "STARTING SONAR"
                        line2 = "PLEASE WAIT..."
                        asd = functions.display_lcd(line1,line2)
                        sonar_ip = resp['sonar_ip']
                        asd = functions.set_systemstatus("Starting SONAR", "7")
                        asd = start_sonar(sonar_ip)

                    elif resp['cmd'] == "stop_sonar":
                        ack_status = ack_cmd(resp['cmd_id'])
                        lcd_off = 0
                        asd = functions.set_systemstatus("Stopping SONAR", "1")
                        asd = stop_sonar()

                    elif resp['cmd'] == "lcd_on":
                        ack_status = ack_cmd(resp['cmd_id'])
                        cmd = "/usr/local/bin/backlight_on"
                        ftemp = functions.cmdline(cmd)
                        id_disp = 0 
                        lcd_off = 0
                        display_standing_guard(0)

                    elif resp['cmd'] == "lcd_off":
                        ack_status = ack_cmd(resp['cmd_id'])
                        cmd = "/usr/local/bin/backlight_off"
                        ftemp = functions.cmdline(cmd)
                        id_disp = 1
                        lcd_off = 1 

                    else:
                        #Unknown command
                        ack_status = ack_cmd(resp['cmd_id'])

                if resp['cmd'] == "none":
                    poll = 1
                    display_trk = display_trk + 1
                    asd = alert_check()
                    if display_trk == 10:
                        display_trk = 0     
                        if issue == 0:
                            if authed == "AUTHORIZED":
                                if not registering:
                                    display_standing_guard(lcd_off)
                            else:
                                display_deviceid(0, lcd_off)
                
                cd = functions.cmdline("/opt/system/countermeasures/cm_daemon.py")
                #if alert_trk == 1:
                #    asd = alert_check()
                  
                comm_error = 0
                time.sleep(poll)
            except Exception as e:                        
                comm_error = comm_error + 1
                print "MAIN LOOP: Comm Error: %s %s\n" % (comm_error, e)
                continue

    except Exception as e:
        print "OUTER LOOP: %s\n" % e
         
def run():
    with daemon.DaemonContext():
        runagent()


if __name__ == "__main__":
    run()

