#!/usr/bin/python

#Copyright 2017 Cybersecurity Defense Soltions. ALL RIGHTS RESERVED
#Update Firmware on Recon Sentinel Devices
#v1.0

from axonchisel.handoff.object import Ax_Handoff
import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import time
import getopt
import sqlite3
from core import functions
from pbkdf2 import crypt
import bcrypt
import requests
import json
#import daemon
from requests.auth import HTTPBasicAuth
from subprocess import call

dbfile = "/opt/system/agent/agent.db"

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)


try:
    sql = "SELECT * FROM agent_config"
    cursor.execute(sql)
    for row in cursor:
        deviceid = row['deviceid']
        password = row['password']
        sharedsecret = row['shared_secret']
except Exception as e:
    print "%s\n" % e


def get_firmware():
    #get rid of any old files jusy in case
    cmd = "/bin/rm /opt/system/getfirmwarechecksum"
    asd = functions.cmdline(cmd)
    cmd = "/bin/rm /opt/system/rsfirmware.tar.gz"
    asd = functions.cmdline(cmd)
    api = functions.get_apiurl()
    url = "%s/_rsupgrade/getfirmware" % (api)
    cmd = "/usr/bin/wget -P /opt/system --http-user=%s --http-password=%s %s" % (deviceid, password, url)
    cmdresult = functions.cmdline(cmd)
    cmd = "/bin/mv /opt/system/getfirmware /opt/system/rsfirmware.tar.gz"
    cmdresult = functions.cmdline(cmd)
    url = "%s/_rsupgrade/getfirmwarechecksum" % (api)
    cmd = "/usr/bin/wget -P /opt/system --http-user=%s --http-password=%s %s" % (deviceid, password, url)
    cmdresult = functions.cmdline(cmd)
    cmd = "/bin/cat /opt/system/getfirmwarechecksum"
    realchecksumraw = functions.cmdline(cmd)
    realchecksumarr = realchecksumraw.split()
    realchecksum = realchecksumarr[0]
    cmd = "/usr/bin/sha256sum /opt/system/rsfirmware.tar.gz"
    suspectchecksumraw = functions.cmdline(cmd)
    suspectchecksumarr = suspectchecksumraw.split()
    suspectchecksum = suspectchecksumarr[0]
    if realchecksum == suspectchecksum:
        functions.mylog("Firmware downloaded, checksums match, upgrading....")
        functions.display_lcd("FIRMWARE", "UPDATING")
        #clean up olf files
        #cmd = "/usr/bin/find /opt/system -name \"*.py\" -type f -delete"
        #asd = functions.cmdline(cmd)
        #expand new firmware
        cmd = "/bin/tar -xzf /opt/system/rsfirmware.tar.gz -C /opt/system"
        asd = functions.cmdline(cmd)
        cmd = "/bin/cp /opt/system/getfirmwarechecksum /opt/system/agent/running_firmware_checksum.txt"
        asd = functions.cmdline(cmd)
        cmd = "/bin/rm /opt/system/getfirmwarechecksum"
        asd = functions.cmdline(cmd)
        cmd = "/bin/rm /opt/system/rsfirmware.tar.gz"
        asd = functions.cmdline(cmd)
        functions.mylog("Firmware update complete, rebooting....")
        cmd = "/sbin/reboot"
        asd = functions.cmdline(cmd)

    else:
        functions.mylog("Firmware downloaded, CHECKSUM MISMATCH.. ABORTING....")
        cmd = "/bin/rm /opt/system/getfirmwarechecksum"
        asd = functions.cmdline(cmd)
        cmd = "/bin/rm /opt/system/rsfirmware.tar.gz"
        asd = functions.cmdline(cmd)
        
def check_for_updates():
    cmd = "/bin/cat /opt/system/agent/running_firmware_checksum.txt"
    running_checksum_raw = functions.cmdline(cmd)
    running_checksum_arr = running_checksum_raw.split()
    running_checksum = running_checksum_arr[0]
    api = functions.get_apiurl()
    url = "%s/_rsupgrade/firmwareversioncheck" % (api)
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
    current_checksum = res.text
    if current_checksum == running_checksum:
        asd = "firmware current"
    else:
        #print current_checksum
        #print running_checksum
        functions.display_lcd("FIRMWARE", "UPDATE")
        functions.mylog("Firmware is out of date, upgrading....")
        get_firmware()
    
if __name__ == "__main__":
    check_for_updates()

