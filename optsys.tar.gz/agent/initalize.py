#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
from core import functions
import sqlite3
import os.path

cmd = "/bin/hostname -I | /usr/bin/awk '{print $1}'"
eth0up = functions.cmdline(cmd)
eth0up = str(eth0up)
eth0up = eth0up.rstrip()

if eth0up:
    asd = functions.display_lcd("PREPARING FOR", "FIRST USE")
    cmd = "/bin/rm /noinit"
    asd = functions.cmdline(cmd)
    cmd = "/opt/system/agent/agent_init.py"
    asd = functions.cmdline(cmd)
    cmd = "/opt/system/agent/pre_register.py"
    asd = functions.cmdline(cmd)
    asd = functions.display_lcd("REBOOTING", " ")
    cmd = "/sbin/reboot -f"
    asd = functions.cmdline(cmd)
else:
    asd = functions.display_lcd("REBOOTING", " ")
    cmd = "/sbin/reboot -f"
    asd = functions.cmdline(cmd)
    
