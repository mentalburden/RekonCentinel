#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
from core import functions
import sqlite3
import os.path
import bcrypt


#cleanup:

#print "Preparing Recon Sentinel for first use...."
asd = functions.cmdline("/bin/rm /opt/system/log/log.txt")
asd = functions.cmdline("/bin/rm /opt/system/log/log.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/log/log.db < /opt/system/log/create_log.sql")
asd = functions.cmdline("/bin/rm /opt/system/alert/alert.txt")
asd = functions.cmdline("/bin/rm /opt/system/alert/alerts.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/alert/alerts.db < /opt/system/alert/create_alert.sql")
asd = functions.cmdline("/bin/rm /opt/system/rdd/hosts.db")
asd = functions.cmdline("/bin/rm /opt/system/rdd/inventory.xml")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/rdd/hosts.db < /opt/system/rdd/create_hosts.sql")
asd = functions.cmdline("/bin/rm /opt/system/traps/traps.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/create_traps.sql")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/initial_traps.sql")
asd = functions.cmdline("/bin/rm /opt/system/countermeasures/countermeasures.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/countermeasures/countermeasures.db < /opt/system/countermeasures/create_countermeasures.sql")


