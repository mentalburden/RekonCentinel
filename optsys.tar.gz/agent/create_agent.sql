CREATE TABLE IF NOT EXISTS agent_config (
    deviceid        TEXT,
    password        TEXT,
    shared_secret   TEXT,
    preregistered   INTEGER default 0,
    registered      INTEGER default 0,
    hash            TEXT
);
