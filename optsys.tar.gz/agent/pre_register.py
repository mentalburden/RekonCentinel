#!/usr/bin/python

import sys
import base64
sys.path.insert(0, "/opt/system/")
import sqlite3
import requests
from core import functions
from Crypto.PublicKey import RSA
from Crypto import Random
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES, PKCS1_OAEP
from requests.auth import HTTPBasicAuth
import os
import random
import string


def id_generator(size=20, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.SystemRandom().choice(chars) for _ in range(size))

dbfile = "/opt/system/agent/agent.db"
init_pass = "9m9WtyYHRsVVfMmTWoe9zjEGPCl4kkCNBTiG9HOJqR8od4hIML"
init_user = "initial"

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)


try:
    reg_log = open("/opt/system/agent/register.log", "a")
    rlog = "STARTING REGISTRATION PROCESS"
    reg_log.write(rlog)
    api = functions.get_apiurl()
    url = "%s/_init/conncheck" % (api)
    res = requests.get(url, auth=HTTPBasicAuth(init_user, init_pass), timeout=30)
    if res.text == "OK":
        sql = "SELECT * FROM agent_config"
        cursor.execute(sql)
        for row in cursor:
            deviceid = row['deviceid']
            hashed = row['hash']
            sharedsecret = row['shared_secret']
            password = row['password']

        filerand = id_generator()
        fname = "/opt/system/agent/%s.bin" % (filerand)
        init_fileout = open(fname, "wb")
        fhandle = open("/usr/local/etc/cust_code", "r")
        cust_code = fhandle.read()
        cust_code = cust_code.rstrip()
        fhandle.close()
        json_initdata = "{\"deviceid\": \"%s\", \"hash\": \"%s\", \"sharedsecret\": \"%s\", \"password\": \"%s\", \"cust_code\": \"%s\"}" % (deviceid, hashed, sharedsecret, password, cust_code)
        b64data = base64.b64encode(json_initdata)
        rskey = RSA.import_key(open("/opt/system/agent/rs_pubkey.key").read())
        session_key = get_random_bytes(16)
        cipher_rsa = PKCS1_OAEP.new(rskey)
        init_fileout.write(cipher_rsa.encrypt(session_key))
        cipher_aes = AES.new(session_key, AES.MODE_EAX)

        ciphertext, tag = cipher_aes.encrypt_and_digest(b64data)
        [ init_fileout.write(x) for x in (cipher_aes.nonce, tag, ciphertext) ]
        init_fileout.close()
        api = functions.get_apiurl()
        url = "%s/_init/preregister" % (api)
        files = {'encfile': open(fname, 'rb')}
        r = requests.post(url, files=files, auth=HTTPBasicAuth(init_user, init_pass), timeout=30)
        if r.text != "OK":
            rlog = "ERROR EXCHANGING DATA WITH API( %s ), DEVICE NOT UPLOADED TO INITIAL DATABASE" % (r.text)
            reg_log.write(rlog)
            cmd = "/usr/bin/touch /noinit"
            asd = functions.cmdline(cmd)
            reg_log.close()
            cmd = "/sbin/reboot -f"
            asd = functions.cmdline(cmd)
        else:
            sql = "UPDATE agent_config SET preregistered = 1 WHERE deviceid = \"%s\"" % (deviceid)
            cursor.execute(sql)
            db.commit()
            rlog = "RECON SENTINEL HAS BEEN PRE-REGISTERED. DEVICEID = \"%s\"" % (deviceid)
            reg_log.write(rlog)
            hn = "/usr/bin/hostnamectl set-hostname %s" % (deviceid)
            asd = functions.cmdline(hn)
            cmd = "/bin/systemctl disable sshd"
            asd = functions.cmdline(cmd)
            #cmd = "/usr/local/bin/i2caddress_detector.py"
            #asd = functions.cmdline(cmd)
        os.remove(fname)
    else:
        rlog = "ERROR CONNECTING TO API: %s" % (res.text)
        reg_log.write(rlog)
        cmd = "/usr/bin/touch /noinit"
        reg_log.close()
        asd = functions.cmdline(cmd)
        cmd = "/sbin/reboot -f"
        asd = functions.cmdline(cmd)

    db.close()
    
except Exception as e:
    cmd = "/usr/bin/touch /noinit"
    asd = functions.cmdline(cmd)
    rlog = "%s\n" % e
    reg_log.write(rlog)
    reg_log.close()
    cmd = "/sbin/reboot -f"
    asd = functions.cmdline(cmd)


