base64 /dev/urandom | head -c 1000 > file.txt
