#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
import os
from core import functions

try:

    cmd = "/bin/ps aux | /bin/grep -v grep | grep -v check_agent.py | /bin/grep agent.py | /bin/grep python | /usr/bin/awk '{print $2}'"
    rdd_pid = functions.cmdline(cmd)
    rdd_pid = str(rdd_pid.rstrip())
    if rdd_pid:
        sys.exit(0)
    else:
        cmd = "/opt/system/agent/agent.py"
        asd = functions.cmdline(cmd)
        sys.exit(0)
except Exception as e:
    print e
