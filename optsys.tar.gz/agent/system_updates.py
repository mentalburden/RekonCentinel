#!/usr/bin/python

#Copyright 2017 Cybersecurity Defense Soltions. ALL RIGHTS RESERVED
#System Updates on Recon Sentinel Devices
#v1.0

from axonchisel.handoff.object import Ax_Handoff
import sys
sys.path.insert(0, "/opt/system/")
import os
import os.path
import datetime
import time
import getopt
import sqlite3
from core import functions
from pbkdf2 import crypt
import bcrypt
import requests
import json
from requests.auth import HTTPBasicAuth
from subprocess import call

dbfile = "/opt/system/agent/agent.db"

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)


try:
    sql = "SELECT * FROM agent_config"
    cursor.execute(sql)
    for row in cursor:
        deviceid = row['deviceid']
        password = row['password']
        sharedsecret = row['shared_secret']
except Exception as e:
    print "%s\n" % e


def get_systemupdates():
    #get rid of any old files jusy in case
    cmd = "/bin/rm /opt/system/sysupdates/getsysupdateschecksum"
    asd = functions.cmdline(cmd)
    cmd = "/bin/rm /opt/system/sysupdates/sysupdates.tar.gz"
    asd = functions.cmdline(cmd)
    api = functions.get_apiurl()
    url = "%s/_rsupgrade/getsysupdates" % (api)
    cmd = "/usr/bin/wget -P /opt/system/sysupdates --http-user=%s --http-password=%s %s" % (deviceid, password, url)
    cmdresult = functions.cmdline(cmd)
    cmd = "/bin/mv /opt/system/sysupdates/getsysupdates /opt/system/sysupdates/sysupdates.tar.gz"
    cmdresult = functions.cmdline(cmd)
    url = "%s/_rsupgrade/getsysupdateschecksum" % (api)
    cmd = "/usr/bin/wget -P /opt/system/sysupdates --http-user=%s --http-password=%s %s" % (deviceid, password, url)
    cmdresult = functions.cmdline(cmd)
    cmd = "/bin/cat /opt/system/sysupdates/getsysupdateschecksum"
    realchecksumraw = functions.cmdline(cmd)
    realchecksumarr = realchecksumraw.split()
    realchecksum = realchecksumarr[0]
    cmd = "/usr/bin/sha256sum /opt/system/sysupdates/sysupdates.tar.gz"
    suspectchecksumraw = functions.cmdline(cmd)
    suspectchecksumarr = suspectchecksumraw.split()
    suspectchecksum = suspectchecksumarr[0]
    if realchecksum == suspectchecksum:
        functions.mylog("System Updates downloaded, checksums match, upgrading....")
        functions.display_lcd("SYSTEM", "UPDATING")
        cmd = "/bin/tar -xzf /opt/system/sysupdates/sysupdates.tar.gz -C /opt/system/sysupdates"
        asd = functions.cmdline(cmd)
        cmd = "/bin/cp /opt/system/sysupdates/getsysupdateschecksum /opt/system/sysupdates/running_sysupdates_checksum.txt"
        asd = functions.cmdline(cmd)
        cmd = "/bin/rm /opt/system/sysupdates/getsysupdateschecksum"
        asd = functions.cmdline(cmd)
        cmd = "/bin/rm /opt/system/sysupdates/sysupdates.tar.gz"
        asd = functions.cmdline(cmd)
        cmd = "/bin/chmod +x /opt/system/sysupdates/sysupdate.sh"
        asd = functions.cmdline(cmd)
        functions.mylog("System updates download complete, rebooting....")
        cmd = "/sbin/reboot"
        asd = functions.cmdline(cmd)

    else:
        functions.mylog("System Updates downloaded, CHECKSUM MISMATCH.. ABORTING....")
        cmd = "/bin/rm /opt/system/sysudpates/getsysupdateschecksum"
        asd = functions.cmdline(cmd)
        cmd = "/bin/rm /opt/system/systemupdates/sysupdates.tar.gz"
        asd = functions.cmdline(cmd)
        
def check_for_updates():
    fname = "/opt/system/sysupdates/running_sysupdates_checksum.txt"
    ftest = os.path.isfile(fname)
    if ftest:
        cmd = "/bin/cat /opt/system/sysupdates/running_sysupdates_checksum.txt"
        running_checksum_raw = functions.cmdline(cmd)
        running_checksum_arr = running_checksum_raw.split()
        running_checksum = running_checksum_arr[0]
        api = functions.get_apiurl()
        url = "%s/_rsupgrade/sysupdatesversioncheck" % (api)
        res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
        current_checksum = res.text
        if current_checksum == running_checksum:
            asd = "systemupdates current"
        else:
            functions.display_lcd("SYSTEM", "UPDATE")
            functions.mylog("SYSTEM is out of date, upgrading....")
            get_systemupdates()
    else:
        functions.display_lcd("SYSTEM", "UPDATE")
        functions.mylog("SYSTEM is out of date, upgrading....")
        get_systemupdates()
    
if __name__ == "__main__":
    check_for_updates()

