#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
from core import functions
import sqlite3
import os.path
import bcrypt

#outfile = "/opt/system/agent/init.txt"
dbfile = "/opt/system/agent/agent.db"

#if os.path.isfile(outfile) is True:
#    print "Init has alreadt been run...exiting"
#    sys.exit(0)

#try:
#    init_file_out = open(outfile, 'w')
#    init_file_out.truncate()
#except:
#    print "Error writing out file %s\n" % (outfile)

#cleanup:

print "Preparing Recon Sentinel for first use...."
asd = functions.cmdline("/bin/rm /opt/system/log/log.txt")
asd = functions.cmdline("/bin/rm /opt/system/log/log.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/log/log.db < /opt/system/log/create_log.sql")
asd = functions.cmdline("/bin/rm /opt/system/alert/alert.txt")
asd = functions.cmdline("/bin/rm /opt/system/alert/alerts.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/alert/alerts.db < /opt/system/alert/create_alert.sql")
asd = functions.cmdline("/bin/rm /opt/system/rdd/hosts.db")
asd = functions.cmdline("/bin/rm /opt/system/rdd/inventory.xml")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/rdd/hosts.db < /opt/system/rdd/create_hosts.sql")
asd = functions.cmdline("/bin/rm /opt/system/traps/traps.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/create_traps.sql")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/traps/traps.db < /opt/system/traps/initial_traps.sql")
asd = functions.cmdline("/bin/rm /opt/system/countermeasures/countermeasures.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/countermeasures/countermeasures.db < /opt/system/countermeasures/create_countermeasures.sql")

asd = functions.cmdline("/bin/rm /opt/system/agent/agent.db")
asd = functions.cmdline("/usr/bin/sqlite3 /opt/system/agent/agent.db < /opt/system/agent/create_agent.sql")



user = functions.cmdline("/usr/bin/pwgen -s 12 1")
user = user.rstrip()
password = functions.cmdline("/usr/bin/pwgen -s 50 1")
password = password.rstrip()
hashedpw = bcrypt.hashpw(password, bcrypt.gensalt(12))
secret = functions.cmdline("/usr/bin/pwgen -s 250 1")
secret = secret.rstrip()

#jsonout = "{\"deviceid\" : \"%s\", \"password\" : \"%s\", \"sharedsecret\" : \"%s\"}" % (user, password, secret)
#sqlout = "INSERT INTO sentinels (deviceid, password, sharedsecret) VALUES (\'%s\', \'%s\', \'%s\')" % (user, hashedpw, secret)
#init_file_out.write(sqlout)
#init_file_out.close()

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

sql = "SELECT * FROM agent_config"
cursor.execute(sql)
test = cursor.fetchone()
if test is True:
    print "there is a error with init... values exist in DB... removing"
    sql = "delete from agent_config"
    cursor.execute(sql)
    db.commit()
    sql = "INSERT INTO agent_config (deviceid, password, shared_secret, hash) VALUES (\'%s\', \'%s\', \'%s\', \'%s\')" % (user, password, secret, hashedpw)
    cursor.execute(sql)
    db.commit()
else:
    sql = "INSERT INTO agent_config (deviceid, password, shared_secret, hash) VALUES (\'%s\', \'%s\', \'%s\', \'%s\')" % (user, password, secret, hashedpw)
    cursor.execute(sql)
    db.commit()
db.close()
