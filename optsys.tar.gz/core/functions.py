#Copyright 2017 Cybersecurity Defense Solutions - ALL RIGHTS RESERVED

import sys
from scapy.all import *
import datetime
import socket
import sqlite3
import smtplib
import re
import random
import netifaces
import time
import SocketServer
import os
import random
from email.mime.text import MIMEText
from subprocess import PIPE, Popen
from axonchisel.handoff.object import Ax_Handoff
import requests
from requests.auth import HTTPBasicAuth


def get_apiurl():
    api = "https://api.reconsentinel.com"
    return api

def get_apidomain():
    apid = "api.reconsentinel.com"
    return apid

def get_ss():
    agentdbfile = "/opt/system/agent/agent.db"
    try:
        agentdb = sqlite3.connect(agentdbfile)
        agentdb.row_factory = sqlite3.Row
        agentcursor = agentdb.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (agentdbfile)

    try:
        sql = "SELECT shared_secret FROM agent_config"
        agentcursor.execute(sql)
        for row in agentcursor:
            sharedsecret = row['shared_secret']
    except Exception as e:
        print "%s\n" % e
    return sharedsecret

def get_devid():
    agentdbfile = "/opt/system/agent/agent.db"
    try:
        agentdb = sqlite3.connect(agentdbfile)
        agentdb.row_factory = sqlite3.Row
        agentcursor = agentdb.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (agentdbfile)

    try:
        sql = "SELECT deviceid FROM agent_config"
        agentcursor.execute(sql)
        for row in agentcursor:
            deviceid = row['deviceid']
    except Exception as e:
        print "%s\n" % e
    return deviceid

def get_pass():
    agentdbfile = "/opt/system/agent/agent.db"
    try:
        agentdb = sqlite3.connect(agentdbfile)
        agentdb.row_factory = sqlite3.Row
        agentcursor = agentdb.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (agentdbfile)

    try:
        sql = "SELECT password FROM agent_config"
        agentcursor.execute(sql)
        for row in agentcursor:
            password = row['password']
    except Exception as e:
        print "%s\n" % e
    return password

def call_post_api(url, postdata):
    agentdbfile = "/opt/system/agent/agent.db"
    try:
        agentdb = sqlite3.connect(agentdbfile)
        agentdb.row_factory = sqlite3.Row
        agentcursor = agentdb.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (agentdbfile)

    try:
        sql = "SELECT * FROM agent_config"
        agentcursor.execute(sql)
        for row in agentcursor:
            deviceid = row['deviceid']
            password = row['password']
            sharedsecret = row['shared_secret']
    except Exception as e:
        print "%s\n" % e

    agentdb.close()
    encdata = Ax_Handoff.encode(postdata, sharedsecret)
    headers = {}
    try:
        res = requests.post(url, data=encdata, headers=headers, auth=HTTPBasicAuth(deviceid, password), timeout=30)
        return res.text
    except:
        print "Not communicating with API, try again later"
    return "ERROR in communicating with %s" % (url)

def cmdline(command):
    process = Popen(
        args=command,
        stdout=PIPE,
        shell=True
    )
    return process.communicate()[0]

def send_status(status):
    deviceid = get_devid()
    password = get_pass()
    api = get_apiurl()

    url = "%s/_status/insert" % (api)
    data = "{\"deviceid\": \"%s\", \"status\": \"%s\", \"password\": \"%s\"}" % (deviceid, status, password)
    api_response = call_post_api(url, data)
    if api_response == "OK":
        return True;
    else:
        return False;

def set_systemstatus(status, state):
    deviceid = get_devid()
    password = get_pass()
    ts = time.time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
    api = get_apiurl()
    url = "%s/_status/system" % (api)
    data = "{\"status\": \"%s\", \"timestamp\": \"%s\", \"state\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (status, timestamp, state,  deviceid, password)
    api_response = call_post_api(url, data)
    if api_response == "OK":
        return True
    else:
        return False

def send_email_alert(subject, message):
    email_to = "noreply@reconsentinel.com"
    email_from = "recon-sentinel@cybersecdefense.com"
    msg = MIMEText(message, 'html')
    msg['Subject'] = subject
    msg['From'] = email_from
    msg['To'] = email_to
    s = smtplib.SMTP('10.125.0.100')
    s.sendmail(email_from, email_to, msg.as_string())
    s.quit()

def mylog(data):
    try:
        dbfile = "/opt/system/log/log.db"
        #logfile = open('/opt/system/log/log.txt', 'a')
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        log = db.cursor()
        now = datetime.datetime.now()
        host = socket.gethostname()
        sync = 0
        log.execute('''INSERT INTO log VALUES (?, ?, ?, ?)''', (now, host, data, sync))
        db.commit()
        rwid = log.lastrowid
        #logfile.write("LOG: Timestamp: %s, Host: %s,  Message: %s\n" % (now, host, data))
        #logfile.close()
        #api
        deviceid = get_devid()
        password = get_pass()
        api = get_apiurl()
        url = "%s/_insert/log" % (api)
        json_log = "{\"deviceid\": \"%s\", \"log_time\": \"%s\", \"hostname\": \"%s\", \"message\": \"%s\", \"password\": \"%s\"}" % (deviceid, now, host, data, password)
        api_response = call_post_api(url, json_log)
        if api_response == "OK":
            #print "Got OK ACK, Log is synced, update db"
            sql = "UPDATE log SET sync = 1 WHERE rowid = %s" % (rwid)
            log.execute(sql)
            db.commit()
            sql = "DELETE FROM log WHERE rowid = %s" % (rwid)
            log.execute(sql)
            db.commit()
        else:
            print "There is an issue with your request: %s" % (api_response)
        db.close()
    except Exception as e:
        print "%s" % (e)

def alert(data, severity, ip, alert_type):
    try:
        dbfile = "/opt/system/alert/alerts.db"
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        alert = db.cursor()

        dbfile2 = "/opt/system/rdd/hosts.db"
        db2 = sqlite3.connect(dbfile2)
        db2.row_factory = sqlite3.Row
        host_info = db2.cursor()
        sql = "SELECT * FROM hosts WHERE ip = \"%s\"" % (ip)
        host_info.execute(sql)
        host = ""
        if host_info:
            for row in host_info:
                host = row['hostname']
                mac = row['mac']
        else:
            host = " "
            mac = " "
        db2.close()
        now = datetime.datetime.now()
        
        #host = socket.gethostname()
        ack = 0
        notified = 0
        sync = 0
        alert.execute('''INSERT INTO alerts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''', (now, host, data, severity, ack, notified, ip, alert_type, sync))
        db.commit()
        rwid = alert.lastrowid
        #api
        deviceid = get_devid()
        password = get_pass()
        api = get_apiurl()
        url = "%s/_insert/alert" % (api)
        json_alert = "{\"deviceid\": \"%s\", \"alert_time\": \"%s\", \"hostname\": \"%s\", \"message\": \"%s\", \"severity\": \"%s\", \"alert_type\": \"%s\", \"ip\": \"%s\", \"mac\": \"%s\", \"password\": \"%s\"}" % (deviceid, now, host, data, severity, alert_type, ip, mac, password)
        api_response = call_post_api(url, json_alert)
        if api_response == "OK":
            #print "Got OK ACK, Alert is synced, update db"
            sql = "UPDATE alerts SET sync = 1 WHERE rowid = %s" % (rwid)
            alert.execute(sql)
            db.commit()
            sql = "DELETE FROM alerts WHERE rowid = %s" % (rwid)
            alert.execute(sql)
            db.commit()
        else:
            print "There is an issue with your request: %s" % (api_response)

        db.close()
    except Exception as e:
         print "ALERT SEND ISSUE %s" % (e)


def remove_device(ip):
    sql_string = "DELETE from hosts WHERE ip = \'%s\'" % (ip)
    cursor.execute(sql_string)
    db.commit()
    sql_string = "DELETE from ports WHERE ip = \'%s\'" % (ip)
    cursor.execute(sql_string)
    db.commit()

def is_valid_ipv4(ip):
    pattern = re.compile(r"""
    ^
    (?:
      # Dotted variants:
      (?:
        # Decimal 1-255 (no leading 0's)
        [3-9]\d?|2(?:5[0-5]|[0-4]?\d)?|1\d{0,2}
      |
        0x0*[0-9a-f]{1,2}  # Hexadecimal 0x0 - 0xFF (possible leading 0's)
      |
        0+[1-3]?[0-7]{0,2} # Octal 0 - 0377 (possible leading 0's)
      )
      (?:                  # Repeat 0-3 times, separated by a dot
        \.
        (?:
          [3-9]\d?|2(?:5[0-5]|[0-4]?\d)?|1\d{0,2}
        |
          0x0*[0-9a-f]{1,2}
        |
          0+[1-3]?[0-7]{0,2}
        )
      ){0,3}
    |
      0x0*[0-9a-f]{1,8}    # Hexadecimal notation, 0x0 - 0xffffffff
    |
      0+[0-3]?[0-7]{0,10}  # Octal notation, 0 - 037777777777
    |
      # Decimal notation, 1-4294967295:
      429496729[0-5]|42949672[0-8]\d|4294967[01]\d\d|429496[0-6]\d{3}|
      42949[0-5]\d{4}|4294[0-8]\d{5}|429[0-3]\d{6}|42[0-8]\d{7}|
      4[01]\d{8}|[1-3]\d{0,9}|[4-9]\d{0,8}
    )
    $
    """, re.VERBOSE | re.IGNORECASE)
    return pattern.match(ip) is not None


class CDSServer(SocketServer.ThreadingTCPServer):
    def __init__(self, server_address, RequestHandlerClass, sensor):
        SocketServer.ThreadingTCPServer.__init__(self,server_address,RequestHandlerClass)
        self.sensor = sensor


class SocketListener((SocketServer.BaseRequestHandler)):

    def handle(self):
        pass


    def setup(self):
        sensor = self.server.sensor
        #length = random.randint(5, 30000) #send random garbage
        #fake_string = os.urandom(int(length))
        #this is where the sending and banning is done
        try:
            ip = self.client_address[0]
            if is_valid_ipv4(ip):
                now = str(datetime.datetime.today())
                ts_now = datetime.datetime.utcnow()
                port = self.server.server_address[1]
                attacked_ip_address = "%s" % (self.server.server_address[0])
                subject = "Recon Sentinel has detected an attack from IP: %s on Port: %s for Trap: %s" % (ip, port, sensor)
                mylog(subject)
                alert(subject, "1", ip, "attack")
                random_pause = random.randint(2, 20)
                time.sleep(random_pause)
                #self.request.send(fake_string)
                self.request.close()

        except Exception, e:
            mylog("Error detecting: " + str(e))
            pass

def listen_server(port,ipaddress,trap_id):
    try:
        port = int(port)
        server = CDSServer(('%s' % ipaddress, port), SocketListener, trap_id)
        mylog("Recon Sentinel is binding to IP: %s Port: %s for Trap: %s" % (ipaddress, port, trap_id))
        server.serve_forever()

    except Exception, e:
        mylog("Recon Sentinal error binding to IP: %s Port %s" % (ipaddress, port))
        mylog("Exception: " + str(e))
        exit()

def arpping(host):
  try:
      ans,unans=srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=host),timeout=2, verbose=0)
      for s,r in ans:
          return r.src
  except Exception, e:
      print e

def check_icmp(ip):
    packet = IP(dst=ip)/ICMP()
    resp = sr1(packet, timeout = 1, verbose=0)
    if resp:
        icmp_type = resp[0][IP].type
        if icmp_type != 0:
            return False
        else:
            src_ip = resp[0].src
            #resp.show()
            return True
    else:
        return False

def check_syn(ip):
    packet = IP(dst=ip)/TCP(dport=443,flags="S")
    resp = sr1(packet, timeout = 1, verbose = 0)
    #icmp_type = resp[0][IP].type
    #src_ip = resp[0].src
    if resp:
        #resp.show()
        src_port = resp[0].sport
        dst_port = resp[0].dport
        #print src_port
        #print dst_port
        send_rst = sr(IP(dst=ip)/TCP(sport=src_port,dport=dst_port,flags="R"),timeout=0.25, verbose=0)
        if resp[0].src != ip:
            return False
        else:
            return True
    else:
        return False

def check_ack(ip):
    packet = IP(dst=ip)/TCP(dport=[80,666],flags="A")
    resp = sr1(packet, timeout = 1, verbose = 0)
    #icmp_type = resp[0][IP].type
    #src_ip = resp[0].src
    if resp:
        #resp.show()
        if resp[0].src != ip:
            return False
        else:
            return True
    else:
        return False

def get_mac_via_arp(ip):
    effort = 0
    while effort <= 10:
        mac = arpping(ip)
        if mac:
            break
        else:
            effort = effort + 1
    return mac

def check_single_icmp_redir(ip):
    packet = IP(dst=ip)/ICMP()
    resp = sr1(packet, timeout = 1, verbose = 0)
    if resp:
        icmp_type = resp[0][IP].type
        if icmp_type == 5:
            asd = "REDIRECT"
            return asd
        else:
            asd = "NORMAL"
            return asd
    else:
        asd = "TIMEOUT"
        return asd

def check_icmp_redirect(ip, testmac):
    check = 0
    icmp_rdr_check = 0
    currmac = get_mac_via_arp(ip)
    currmac = str(currmac.rstrip())
    testmac = str(testmac.rstrip())
    currmac = currmac.upper()
    testmac = testmac.upper()
    print currmac
    print testmac
    if testmac != currmac:
        icmp_rdr_check = 1
    else:
        while check <= 10:
            icmp_redir = check_single_icmp_redir(ip)
            if icmp_redir == "REDIRECT":
                icmp_rdr_check = 1
                break
            elif icmp_redir == "NORMAL":
                check = check + 1
            elif icmp_redir == "TIMEOUT":
                check = check + 1
            else:
                check = check + 1

    if icmp_rdr_check == 1:
        return True
    else:
        return False

def is_device_up(ip):
    try:
        asd = None
        try:
            ans,unans=srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=ip),retry=4, timeout=1, verbose=0)
            for s,r in ans:
                asd = r.src
                asd = asd.rstrip()
        except Exception, e:
            print e
    
        if asd is not None:
            return True
        else:
            return False
#
#        asd = check_icmp(ip)
#        if asd is True:
#            return True
#        else:
#            asd1 = check_icmp(ip)
#            if asd1 is True:
#                return True
#            else:
#                asd2 = check_syn(ip)
#                if asd2 is True:
#                    return True
#                else:
#                    asd3 = check_ack(ip)
#                    if asd3 is True:
#                        return True
#                    else:
#                        return False


#        packet = IP(dst=ip)/ICMP()
#        resp = sr1(packet, timeout = 1, verbose = 0)
#        if resp:
#            icmp_type = resp[0][IP].type
#            if icmp_type == 5:
#                chkrdr = True
#            else:
#                chkrdr = False
#        else:
#            chkrdr = False
#
#        if chkrdr is True:
#            return False
#        else:
#            devstat = os.system("ping -c 2 -w2 " + ip  + " > /dev/null 2>&1")
#            if devstat == 0:
#                return True
#            else:
#                cmd = "/usr/bin/nmap -sn %s | /bin/grep \"1 host up\"" % (ip)
#                test2 = cmdline(cmd)
#                if test2 != "":
#                    return True
#                else:
#                    return False
    except Exception, e:
        mylog("Device Up Detection Exception: " + str(e))
        return False

def display_lcd(line1, line2):
    try:
        cmd = "/opt/system/agent/lcd_display.py \"%s\" \"%s\"" % (line1, line2)
        asd = cmdline(cmd)
        return True
    except:
        return False


def get_mac_manufacturer(mac):
    deviceid = get_devid()
    password = get_pass()
    sharedsecret = get_ss()
    api = get_apiurl()

    cmd = "{\"cmd\": \"get_mac_manufacturer\", \"deviceid\": \"%s\", \"password\": \"%s\", \"mac_address\": \"%s\"}" % (deviceid, password, mac)
    encdata = Ax_Handoff.encode(cmd, sharedsecret)
    url = "%s/_check/%s" % (api, encdata)
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password), timeout=30)
    manufacturer = Ax_Handoff.decode(res.text, sharedsecret)
    return manufacturer

def get_local_ip():
    cmd = "/bin/hostname -I | /usr/bin/awk '{print $1}'"
    local_ip = cmdline(cmd)
    local_ip = str(local_ip.rstrip())
    return local_ip

def get_local_netmask():
    cmd = "/sbin/ifconfig | /bin/grep 'inet addr' | /usr/bin/awk '{print $4}' | /bin/grep Mask | /usr/bin/awk -F: '/Mask:/{ print $2}'"
    local_netmask = cmdline(cmd)
    local_netmask = str(local_netmask.rstrip())
    return local_netmask

def get_local_network():
    local_ip = get_local_ip()
    local_mask = get_local_netmask()
    cmd = "/usr/bin/ipcalc -n %s %s | /bin/grep Network | /usr/bin/awk '{print $2}'" % (local_ip, local_mask)
    local_net = cmdline(cmd)
    local_net = str(local_net.rstrip())
    return local_net

def get_port_info(ip, port, field):
    dbfile = "/opt/system/rdd/hosts.db"
    try:
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (dbfile)
        sys.exit(0)
    sql = "SELECT %s FROM ports WHERE ip = \"%s\" AND port = \"%s\"" % (field, ip, port)
    cursor.execute(sql)
    for row in cursor:
        retval = row[field]
    return retval
    db.close()

def update_port_record(ip, field, value, port):
    dbfile = "/opt/system/rdd/hosts.db"
    try:
        db = sqlite3.connect(dbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (dbfile)
        sys.exit(0)

    sql = "SELECT mac FROM hosts WHERE ip = \"%s\"" % (ip)
    cursor.execute(sql)
    for row in cursor:
        mac = row['mac']
    #api
    deviceid = get_devid()
    password = get_pass()
    api = get_apiurl()
    url = "%s/_update/portrecord" % (api)
    portrecord = "{\"field\": \"%s\", \"value\": \"%s\", \"deviceid\": \"%s\", \"ip\": \"%s\", \"port\": \"%s\", \"mac\": \"%s\", \"password\": \"%s\"}" % (field, value, deviceid, ip, port, mac, password)
    api_response = call_post_api(url, portrecord)
    if api_response == "OK":
        sql_string = "UPDATE ports SET %s = \"%s\", sync = \"1\" WHERE ip = \'%s\' AND port = \"%s\"" % (field, value, ip, port)
        cursor.execute(sql_string)
        db.commit()
        print "Got OK ACK, Record Updated"
    else:
        sql_string = "UPDATE ports SET %s = \"%s\", sync = \"0\" WHERE ip = \'%s\' AND port = \"%s\"" % (field, value, ip, port)
        cursor.execute(sql_string)
        db.commit()
        print "There is an issue with your request: %s" % (api_response)

    db.close()


def insert_host_db(ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized):
    sync = 0
    try:
       #if not mac_vendor:
       mac_vendor = get_mac_manufacturer(mac)
       cursor.execute('''INSERT INTO hosts (ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, last_update, state, mac_vendor, whois, authorized, sync) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (ip, mac, protocol, os_name, os_vendor, os_family, os_accuracy, os_gen, timestamp, state, mac_vendor, whois_str, authorized, sync))
       db.commit()
    except Exception as e:
        print "whoops: %s" % (e)


    deviceid = get_devid()
    password = get_pass()
    api = get_apiurl()
    url = "%s/_insert/hosts" % (api)

    hostdata = "{\"deviceid\": \"%s\", \"ip\": \"%s\", \"mac\": \"%s\", \"protocol\": \"%s\", \"os_name\": \"%s\", \"os_vendor\": \"%s\"," % (deviceid, ip, mac, protocol, os_name, os_vendor)
    hostdata += "\"os_family\": \"%s\", \"os_accuracy\": \"%s\", \"os_gen\": \"%s\", \"timestamp\": \"%s\", \"state\": \"%s\", \"mac_vendor\": \"%s\"," % (os_family, os_accuracy, os_gen, timestamp, state, mac_vendor)
    hostdata += "\"whois_str\": \"%s\", \"authorized\": \"%s\", \"password\": \"%s\"}" % (whois_str, authorized, password)

    api_response = call_post_api(url, hostdata)

    if api_response == "OK":
        print "Got OK ACK, Record is synced, update db"
        sql = "UPDATE hosts SET sync = 1 WHERE ip = \"%s\" AND mac = \"%s\"" % (ip, mac)
        cursor.execute(sql)
        db.commit()
    else:
        print "There is an issue with _insert/hosts api: %s" % (api_response)


