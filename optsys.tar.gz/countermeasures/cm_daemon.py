#!/usr/bin/python
## cm_daemon.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# cm_daemon will read countermeasure configs from the database, start/stop countermeasures as needed
# version 1.1 - 5/4/2017

import sys
from scapy.all import *
sys.path.insert(0, "/opt/system/")
import os
import sqlite3
from core import functions
import requests
import json
from axonchisel.handoff.object import Ax_Handoff
from requests.auth import HTTPBasicAuth


#check which countermeasures should be running
dbfile = "/opt/system/countermeasures/countermeasures.db"
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    c = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def check_command():
    agentdbfile = "/opt/system/agent/agent.db"
    try:
        db = sqlite3.connect(agentdbfile)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
    except:
        print "Error connecting to dbfile: %s\n" % (dbfile)
    try:
        sql = "SELECT * FROM agent_config"
        cursor.execute(sql)
        for row in cursor:
            deviceid = row['deviceid']
            password = row['password']
            sharedsecret = row['shared_secret']
    except Exception as e:
        print "agent_config: %s\n" % e
    db.close()
    data1 = "{\"deviceid\": \"%s\", \"password\": \"%s\", \"ask\": \"getcmd\"}" % (deviceid, password)
    encdata = Ax_Handoff.encode(data1, sharedsecret)
    api = functions.get_apiurl()
    url = "%s/_cmd/%s" % (api, encdata)
    headers = {}
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
    json_data = Ax_Handoff.decode(res.text, sharedsecret)
    return json_data




def get_running_mac(ip):
    cmd = "/bin/ps uaxww | /bin/grep -v grep | /bin/grep countermeasure1.py | /bin/grep -w \"%s\" | /usr/bin/awk '{print $16}'" % (ip)
    running_mac = functions.cmdline(cmd)
    running_mac = running_mac.rstrip()
    #print "GET RUNNING MAC"
    #print cmd
    #print running_mac
    return running_mac


def get_target_mac(ip):
    target_mac = ""
    hostfile = "/opt/system/rdd/hosts.db"
    db1 = sqlite3.connect(hostfile)
    db1.row_factory = sqlite3.Row
    c1 = db1.cursor()
    sql = "SELECT mac FROM hosts WHERE ip = \"%s\"" % (ip)
    #print sql
    c1.execute(sql)
    for row in c1:
        target_mac = row['mac']
    db1.close()
    if target_mac:
        return target_mac
    else: 
        return False

def check_target_ip(mac):
    localnet = functions.get_local_network()
    cmd = "/usr/bin/nmap -sn %s -T4 | /bin/grep -w -B 2 \"%s\" | /bin/grep Nmap | /usr/bin/awk '{print $5}'" % (localnet, mac)
    target_ip = functions.cmdline(cmd)
    target_ip = target_ip.rstrip()
    #print "CHECK TARGET IP"
    #print cmd
    #print target_ip
    return target_ip

def kill_cm(ip):
    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep countermeasure1 | /bin/grep python | /bin/grep -w \"%s\" | /usr/bin/awk '{print $2}'" % (ip)
    pid = functions.cmdline(cmd)
    pid = pid.rstrip()
    cmd = "/bin/kill -2 %s" % (pid)
    killit = functions.cmdline(cmd)

def start_cm(ip):

    gateway = functions.cmdline("/opt/system/countermeasures/get_gw.sh")
    gateway = gateway.rstrip()
    cmd = "/opt/system/countermeasures/countermeasure1.py -i eth0 -t %s %s" % (gateway, ip)
    asd = functions.cmdline(cmd)

#this function is not needed   
def update_cm_records(ip, mac):
    #api
    deviceid = functions.get_devid()
    password = functions.get_pass()
    api = functions.get_apiurl()
    hostfile = "/opt/system/rdd/hosts.db"
    db1 = sqlite3.connect(hostfile)
    db1.row_factory = sqlite3.Row
    cursor = db1.cursor()
    sql = "SELECT ip FROM hosts WHERE mac = \"%s\"" % (mac)
    cursor.execute(sql)
    for row in cursor:
        oldip = row['ip']

    url = "%s/_update/iprecord" % (api)
    hostrecord = "{\"ip\": \"%s\", \"mac\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (ip, mac, deviceid, password)
    api_response = functions.call_post_api(url, hostrecord)
    if api_response == "OK":
        sql_string = "UPDATE hosts SET ip = \"%s\", sync = \"1\" WHERE mac = \"%s\"" % (ip, mac)
        cursor.execute(sql_string)
        db1.commit()
        sql_string = "UPDATE ports SET ip = \"%s\" WHERE ip = \"%s\"" % (ip, oldip)
        cursor.execute(sql_string)
        db1.commit()
        url = "%s/_update/countermeasure" % (api)
        hostrecord = "{\"old_ip\": \"%s\", \"new_ip\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (oldip, ip, deviceid, password)
        api_response = functions.call_post_api(url, hostrecord)
        if api_response == "OK":
            return True
        else:
            functions.mylog("There is an issue posting to _update/countermeasures %s" % (api_response))
            return False
    else:
        functions.mylog("There is an issue posting to _update/iprecord: %s" % (api_response))
        sql_string = "UPDATE hosts SET ip = \"%s\", sync = \"2\" WHERE mac = \'%s\'" % (ip, mac)
        cursor.execute(sql_string)
        db.commit()
        return False

    db1.close()

try:
    command = check_command()
    resp = json.loads(command)
    if resp['cmd'] != "none":
        sys.exit(0)


    #cmd = "/bin/hostname -I | /usr/bin/awk '{print $1}'"
    #local_ip = functions.cmdline(cmd)
    #local_ip = local_ip.rstrip()

    sql = "SELECT * FROM countermeasures WHERE active = 0"
    c.execute(sql)
    for row in c:
        cmtarget = row['target_ip']
        #see if cm is running
        cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep countermeasure1 | /bin/grep python | /bin/grep -w \"%s\"" % (cmtarget)
        cm_run = functions.cmdline(cmd)
        cm_run = str(cm_run.rstrip())
        if cm_run:
            kill_cm(cmtarget)
        #else:
            sql = "DELETE FROM countermeasures WHERE target_ip = '%s'" % (cmtarget)
            c.execute(sql)
            db.commit()
            asd = functions.display_lcd("ACTIVE DEFENSE", "CM STOPPED")
            sys.exit(0)

    sql = "SELECT * FROM countermeasures WHERE active = 1"
    c.execute(sql)
    for row in c:
        asd = functions.display_lcd("ACTIVE DEFENSE", "CM RUNNING")
        cmtarget = row['target_ip']
        #see if cm is running
        cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep countermeasure1 | /bin/grep python | /bin/grep -w \"%s\"" % (cmtarget)
        cm_run = functions.cmdline(cmd)
        cm_run = str(cm_run.rstrip())

        #This is the mac tracking section, but it needs work
        if cm_run:
            tempshit = 0
        #    #check if the current target is up
        #    running_mac = get_running_mac(cmtarget)
        #    check_t_ip = check_target_ip(running_mac)
        #    if check_t_ip != cmtarget:
        #        if check_t_ip:
        #            #houston, we have a problem..
        #            kill_cm(cmtarget)
        #            #print "Starting cm 2"
        #            start_cm(check_t_ip, running_mac)
        #            sql = "UPDATE countermeasures SET target_ip = \"%s\" WHERE target_ip = \"%s\"" % (check_t_ip, cmtarget)
        #            c.execute(sql)
        #            db.commit()
        #            asd = update_cm_records(check_t_ip, running_mac)
        #            #print asd
            
        else:
            #gateway = functions.cmdline("/opt/system/countermeasures/get_gw.sh")
            #gateway = gateway.rstrip()
            # the -r is suspect - it can cause network issues
            #cmd = "/opt/system/countermeasures/countermeasure1.py -i eth0 -t %s %s -r" % (cmtarget, gateway)
            #cmd = "/opt/system/countermeasures/countermeasure1.py -i eth0 -t %s %s" % (cmtarget, gateway)
            #cmd = "/opt/system/countermeasures/countermeasure1.py -i eth0 -t 254.254.254.254 %s" % (cmtarget)
            #cmd = "/opt/system/countermeasures/countermeasure1.py -i eth0 -t %s %s" % (local_ip, cmtarget)
            #cmd = "/opt/system/countermeasures/countermeasure2.py %s" % (cmtarget)
            
            #print "startin cm 1"

            #cm_target_mac = get_target_mac(cmtarget)
            #cm_target_mac = 1
            #if cm_target_mac:
            start_cm(cmtarget)

    db.close()
except Exception as e:
    print e
