CREATE TABLE IF NOT EXISTS countermeasures (
    target_ip       VARCHAR(32),
    active          INTEGER
);
