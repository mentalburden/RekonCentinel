#!/bin/sh

NM=$(/sbin/ip route | /usr/bin/awk '/default/ { print $3 }')

echo $NM
