CREATE TABLE IF NOT EXISTS traps (
    name            VARCHAR(129),
    description     TEXT,
    port            INTEGER,
    active          INTEGER
);
