#!/usr/bin/python

#Copyright 2015 Cybersecurity Defense Solutions - by Gregory P. Scasny
#This work as been adapted from Twisted Matrix Labs and Artillery from Binary Defense Systems

from twisted.python import log
import sys
sys.path.insert(0, "/opt/system/")
import thread
import daemon
import subprocess
from sys import argv
from core import functions


try:
    argv[3]
except IndexError:    
    print '''
Usage: general_TCP_trap.py [IP] [Port]
i.e. general_TCP_trap.py 192.168.1.2 2387
IP Address must be available on the system. 
Written by: Greg Scasny
''' 
    exit()

IP_Address = argv[1]
Port = int(argv[2])
trap_ID = argv[3]


def trap(port, ipaddress, trap_id):
    thread.start_new_thread(functions.listen_server(port,ipaddress,trap_id))
    log.startLogging(sys.stderr)

def run():
    with daemon.DaemonContext():
        trap(Port, IP_Address, trap_ID)

if __name__ == "__main__":
    run()
