#!/usr/bin/python
## trap_daemon.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# trap_daemon will read honeyport config from the database, start/stop honeyports as needed

import sys
sys.path.insert(0, "/opt/system/")
import os
import sqlite3
from core import functions


#check which traps should be running
dbfile = "/opt/system/traps/traps.db"
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    c = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

try:
   sql = "SELECT * FROM traps WHERE active = 1"
   c.execute(sql)
   for row in c:
       trapname = row['name']
       trapport = row['port']
       #see if trap is running
       cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep trap | /bin/grep python | /bin/grep -w %s | /bin/grep %s | /usr/bin/awk '{print $14}'" % (trapname, trapport)
       rtrap_p = functions.cmdline(cmd)
       rtrap_p = str(rtrap_p.rstrip())
       port1 = trapport
       trapport = str(trapport)
       if rtrap_p != trapport: 
           print "Trap %s is not running, starting..." % (trapname)
           localip = functions.cmdline("/bin/hostname -I | /usr/bin/awk '{print $1}'")
           localip = localip.rstrip()
           cmd = "/opt/system/traps/trap.py %s %s %s" % (localip, port1, trapname)
           asd = functions.cmdline(cmd)

   sql = "SELECT * FROM traps WHERE active = 0"
   c.execute(sql)
   for row in c:
       trapname = row['name']
       trapport = row['port']
       #see if trap is running
       cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep trap | /bin/grep python | /bin/grep %s | /bin/grep -w %s | /usr/bin/awk '{print $14}'" % (trapport, trapname)
       rtrap_p = functions.cmdline(cmd)
       rtrap_p = str(rtrap_p.rstrip())
       trapport = str(trapport)
       if rtrap_p == trapport: 
           #print "TRAP %s is running on port %s" % (trapname, trapport)
           cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep trap | /bin/grep python | /bin/grep %s | /bin/grep -w %s | /usr/bin/awk '{print $2}'" % (trapport, trapname)
           pid = functions.cmdline(cmd)
           pid = pid.rstrip()
           cmd = "/bin/kill -9 %s" % (pid)
           killit = functions.cmdline(cmd)


except Exception as e:
    print e
