#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import time
import getopt
import sqlite3
from core import functions


alertdbfile = "/opt/system/alert/alerts.db"
hostsdbfile = "/opt/system/rdd/hosts.db"

def main():
    try:
        try:
            db = sqlite3.connect(alertdbfile)
            db.row_factory = sqlite3.Row
            cursor = db.cursor()
        except:
            print "Error connecting to dbfile: %s\n" % (dbfile)


        message = '''<html><head>
	<style type="text/css">body {
  background-color:white;
  }
	</style>
	<title></title>
</head>
<body>
<table align="center" border="0" cellpadding="10" cellspacing="0" style="background-color:white;width:100%;">
	<tbody>
		<tr>
			<td>
			<p><span style="font-size:9px;"><img alt="" height="103" src="https://www.cybersecdefense.com/rs-images/recon_sentinel_logo.png" width="500" /></span></p>
			</td>
		</tr>
		<tr style="background-color:#CCCCCC;">
			<td>
			<p><span style="font-size:9px;"><img alt="" height="30" src="https://www.cybersecdefense.com/rs-images/alert.png" width="119" /></span></p>
			</td>
		</tr>
	</tbody>
</table>
<p>&nbsp;</p>
<p><span style="color:#FF0000;"><strong><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">This is an alert from your Recon Sentinel Device.</span></strong></span></p>
'''
        subject = "Alert from Recon Sentinel"

        timestmp = {}
        hostname = {}
        alert = {}
        severity = {}
        notified = {}
        alert_type = {}
        notify = {}
        alert_ip = {}
        cursor.execute(''' SELECT rowid, * FROM alerts WHERE ack = 0 AND notified = 0 AND severity <= 2''')
        sendable_alerts = cursor.fetchone()
        if sendable_alerts is None:
            print "There are no alerts at this time\n"
        else:
            cursor.execute(''' SELECT rowid, * FROM alerts WHERE ack = 0 AND notified = 0 and severity <= 2 ORDER BY alert_time ASC''')
            for row in cursor:
                alert_id = row['rowid']
                timestmp[alert_id] = row['alert_time']
                hostname[alert_id] = row['hostname']
                alert[alert_id] = row['message']    
                severity[alert_id] = row['severity']
                #notified[alert_id] = row['notified']
                alert_type[alert_id] = row['alert_type']
                alert_ip[alert_id] = row['ip']
            
            headtrack = 0
            for alertid in timestmp:
                if (alert_type[alertid] == "attack") or (alert_type[alertid] == "scan"):
                    message += '''<p><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "At %s, %s" % (timestmp[alertid], alert[alertid])
                    message += '''</span></p>'''
                    notify[alertid] = 1
                if (alert_type[alertid] == "rogue"):
                    if headtrack == 0:
                        message += '''<p><strong><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">The Following Unauthorized Devices were found on your network:</span></strong></p>'''
                        headtrack = 1
                    try:
                        db1 = sqlite3.connect(hostsdbfile)
                        db1.row_factory = sqlite3.Row
                        cursor1 = db1.cursor()
                    except:
                        print "Error connecting to dbfile: %s\n" % (hostsdbfile)
                    cursor1.execute('''SELECT * FROM hosts WHERE ip = ?''', (alert_ip[alertid],))
                    for row1 in cursor1:
                        r_ip = row1['ip']
                        r_mac = row1['mac']
                        r_osfamily = row1['os_family']
                        r_osvendor = row1['os_vendor']
                        r_macvendor = row1['mac_vendor']
                        r_hostname = row1['hostname']

                    message += '''<p><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "At %s, a Rogue Device was detected on your network<br> It has the following characteristics:</span></p>" % (timestmp[alertid])
                    message += '''<ul>'''
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The IP Address is %s</span></li>" % (r_ip)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The MAC Address is %s</span></li>" % (r_mac)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The manufacturer of the network card is %s</span></li>" % (r_macvendor)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The Operating System is %s</span></li>" % (r_osfamily)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The Hostname is %s</span></li>" % (r_hostname)
                    message += '''</ul>'''
                    notify[alertid] = 1

                if (alert_type[alertid] == "rogueonly"):
                    try:
                        db2 = sqlite3.connect(hostsdbfile)
                        db2.row_factory = sqlite3.Row
                        cursor2 = db2.cursor()
                    except:
                        print "Error connecting to dbfile: %s\n" % (dbfile)

                    cursor2.execute('''SELECT * FROM hosts WHERE ip = ?''', (alert_ip[alertid],))
                    for row2 in cursor2:
                        ro_ip = row2['ip']
                        ro_mac = row2['mac']
                        ro_osfamily = row2['os_family']
                        ro_osvendor = row2['os_vendor']
                        ro_macvendor = row2['mac_vendor']
                        ro_hostname = row2['hostname']

                    message += '''<p><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "At %s, a Rogue Device was detected on your network<br> It has the following characteristics:</span></p>" % (timestmp[alertid])
                    message += '''<ul>'''
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The IP Address is %s</span></li>" % (ro_ip)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The MAC Address is %s</span></li>" % (ro_mac)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The manufacturer of the network card is %s</span></li>" % (ro_macvendor)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The Operating System is %s</span></li>" % (ro_osfamily)
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "The Hostname is %s</span></li>" % (ro_hostname)
                    message += "</ul>"
                    notify[alertid] = 1
  
            headtrack = 0
            for alertid in timestmp:
                if (alert_type[alertid] == "rogueservice"):
                    if headtrack == 0:
                        message += ''' <br><hr><br><p><strong><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">The Following Unauthorized Network Services &nbsp;were found on your network:</span></strong></p>'''
                        headtrack = 1
                    message += '''<p><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "At %s on IP Address: %s, the following was detected:" % (timestmp[alertid], alert_ip[alertid])
                    message += '''</span></p>''' 
                    message += "<ul>"
                    message += '''<li><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">'''
                    message += "%s" % (alert[alertid])
                    message += '''</span></li>'''
                    message += '''</ul>'''
                    notify[alertid] = 1




            message += '''<p>&nbsp;</p>

<table border="0" cellpadding="10" cellspacing="1" style="width:100%;background-color:black;">
	<tbody>
		<tr>
			<td>
			<pre>
<span style="color:#E6E6FA;"><tt><span style="font-size: 11px;"><span style="font-family: &quot;lucida sans unicode&quot;, &quot;lucida grande&quot;, sans-serif;">Recon Sentinel&copy; - Copyright 2017 Cybersecurity Defense Solutions, LLC</span></span></tt>
<tt><span style="font-size: 11px;"><span style="font-family: &quot;lucida sans unicode&quot;, &quot;lucida grande&quot;, sans-serif;">ALL RIGHTS RESERVED</span></span></tt></span></pre>

			<p><span style="color:#E6E6FA;"><tt><span style="font-size: 11px;"><span style="font-family: &quot;lucida sans unicode&quot;, &quot;lucida grande&quot;, sans-serif;"><form action="http://www.reconsentinel.com/index.html"><input name="Access Your Recon Sentinel" type="submit" value="Access Your Recon Sentinel" /></form></span></span></tt></span></p>
			</td>
		</tr>
	</tbody>
</table>

<pre>&nbsp;</pre>
<p>&nbsp;</p>
</body>
</html>'''
            functions.send_email_alert(subject, message)

            for notify_id in notify:
                sql_str = "UPDATE alerts SET notified = %s where rowid = %s" % (notify[notify_id], notify_id)
                cursor.execute(sql_str)
                db.commit()
            db.close()

    #except Exception as e:
    except ValueError as e:
        print "Exception: %s\n" % e

if __name__ == "__main__":
    main()
    sys.exit(0)


