#!/usr/bin/python

import sys
import os
import datetime
import getopt
import sqlite3

dbfile = "/opt/system/alert/alerts.db"
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def main():
    try:
        #alert_id = {}
        timestmp = {}
        hostname = {}
        alert = {}
        severity = {}
        ack = {}
        notified = {}
        alert_type = {}
        cursor.execute(''' SELECT rowid, * FROM alerts WHERE ack = 0''')
        ackable_alerts = cursor.fetchone()
        if ackable_alerts is None:
            print "There are no unackowledged alerts at this time\n"
        else:
            cursor.execute(''' SELECT rowid, * FROM alerts WHERE ack = 0''')
            for row in cursor:
                alert_id = row['rowid']
                timestmp[alert_id] = row['alert_time']
                hostname[alert_id] = row['hostname']
                alert[alert_id] = row['message']    
                severity[alert_id] = row['severity']
                notified[alert_id] = row['notified']
                alert_type[alert_id] = row['alert_type']
            for alertid in timestmp:
                print "%s : %s Alert Type: %s Severity: %s\n\n" % (timestmp[alertid], alert[alertid], alert_type[alertid], severity[alertid])
                rogue = raw_input("Do you want to acknowledge the above alert? (Y/N) DEFAULT = Y: ")
                if rogue == "Y":
                    print "Acknowledging Alert..\n"
                    ack[alertid] = 1
                elif rogue == "N":
                    print "Leaving Alert ACTIVE\n"
                    ack[alertid] = 0
                else:
                    print "Acknowledging Alert..\n"
                    ack[alertid] = 1

            for ack_id in ack:
                sql_str = "UPDATE alerts SET ack = %s where rowid = %s" % (ack[ack_id], ack_id)
                cursor.execute(sql_str)
                db.commit()
        db.close()

    except Exception as e:
        print "%s\n" % e

if __name__ == "__main__":
    main()
    sys.exit(0)


