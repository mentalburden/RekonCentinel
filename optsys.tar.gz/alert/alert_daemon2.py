#!/usr/bin/python

import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import time
import getopt
import sqlite3
from core import functions


dbfile = "/opt/system/alert/alerts.db"

def main():
    try:
        while True:
            try:
                db = sqlite3.connect(dbfile)
                db.row_factory = sqlite3.Row
                cursor = db.cursor()
            except:
                print "Error connecting to dbfile: %s\n" % (dbfile)

            timestmp = {}
            hostname = {}
            alert = {}
            severity = {}
            notified = {}
            alert_type = {}
            notify = {}
            message = "This is a alert from your HACKERTRAPPER...\n\n"
            subject = "Alert from Rogue Device Detection"
            cursor.execute(''' SELECT rowid, * FROM alerts WHERE ack = 0 AND notified = 0 AND severity <= 2''')
            sendable_alerts = cursor.fetchone()
            if sendable_alerts is None:
                print "There are no unackowledged alerts at this time\n"
            else:
                cursor.execute(''' SELECT rowid, * FROM alerts WHERE ack = 0 AND notified = 0 and severity <= 2 ORDER BY alert_time ASC''')
                for row in cursor:
                    alert_id = row['rowid']
                    timestmp[alert_id] = row['alert_time']
                    hostname[alert_id] = row['hostname']
                    alert[alert_id] = row['message']    
                    #severity[alert_id] = row['severity']
                    #notified[alert_id] = row['notified']
                    alert_type[alert_id] = row['alert_type']

                message += "The Following Unauthorized Devices were found on your network:\n\n" 
                for alertid in timestmp:
                    if (alert_type[alertid] == "rogue"):
                        message += "At %s, A %s \n\n" % (timestmp[alertid], alert[alertid])
                        notify[alertid] = 1
    
                message += "The Following Unauthorized Network Services  were found on your network:\n\n" 
                for alertid in timestmp:
                    if (alert_type[alertid] == "rogueservice"):
                        message += "At %s, A %s \n\n" % (timestmp[alertid], alert[alertid])
                        notify[alertid] = 1
          
                functions.send_email_alert(subject, message)
    
                for notify_id in notify:
                    sql_str = "UPDATE alerts SET notified = %s where rowid = %s" % (notified[notify_id], notify_id)
                    #cursor.execute(sql_str)
                    #db.commit()
                time.sleep(300)
                db.close()

        except Exception as e:
            print "%s\n" % e

if __name__ == "__main__":
    main()
    sys.exit(0)


