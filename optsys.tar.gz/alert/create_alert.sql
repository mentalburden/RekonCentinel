CREATE TABLE IF NOT EXISTS alerts (
    alert_time	TIMESTAMP,
    hostname    VARCHAR(129),
    message     TEXT,
    severity	INTEGER,
    ack		INTEGER,
    notified    INTEGER,
    ip          VARCHAR(16),
    alert_type        VARCHAR(129),
    sync        INTEGER
);
