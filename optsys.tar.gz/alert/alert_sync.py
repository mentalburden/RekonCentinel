#!/usr/bin/python
## alert_sync.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# This sync will sync alerts changes between the recon sentinel and the API when the recon sentiel is unable to talk to the API


import sys
sys.path.insert(0, "/opt/system/")
import os
import datetime
import getopt
import xml.dom.minidom
import sqlite3
from core import functions
from axonchisel.handoff.object import Ax_Handoff
import requests
from requests.auth import HTTPBasicAuth

dbfile = "/opt/system/alert/alerts.db"

try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)
    sys.exit(0)

try:
    sharedsecret = functions.get_ss()
    deviceid = functions.get_devid()
    password = functions.get_pass()
    cmd = "{\"cmd\": \"conntest\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (deviceid, password)
    encdata = Ax_Handoff.encode(cmd, sharedsecret)
    api = functions.get_apiurl()
    url = "%s/_check/%s" % (api, encdata)
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
    connection_status = Ax_Handoff.decode(res.text, sharedsecret)
    if connection_status == "CONNECTED":
        alert_trk = {}
        sql = "SELECT rowid, * FROM alerts WHERE sync = 0"
        cursor.execute(sql)
        for row in cursor:
            url = "%s/_insert/alert" % (api)
            json_alert = "{\"deviceid\": \"%s\", \"alert_time\": \"%s\", \"hostname\": \"%s\", \"message\": \"%s\", \"severity\": \"%s\", \"alert_type\": \"%s\", \"ip\": \"%s\", \"password\": \"%s\"}" % (deviceid, row['alert_time'], row['hostname'], row['message'], row['severity'], row['alert_type'], row['ip'], password)

            api_response = functions.call_post_api(url, json_alert)

            if api_response == "OK":
                alert_trk[row['rowid']] = row['rowid']
            else:
                print "There is an issue with your request: %s" % (api_response)

    for rwid in alert_trk:
        print "Got OK ACK, Alert is synced, update db"
        sql = "UPDATE alerts SET sync = 1 WHERE rowid = %s" % (rwid)
        cursor.execute(sql)
        db.commit()
        sql = "DELETE FROM alerts WHERE rowid = %s" % (rwid)
        cursor.execute(sql)
        db.commit()

    db.close()
except Exception as e:
     print "Problem connecting to API %s" % (e)
            
    
