#!/usr/bin/python

import sys
import os
import datetime
import getopt
import sqlite3

dbfile = "/opt/system/alert/alerts.db"
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)

def main():
    try:
        timestmp = {}
        hostname = {}
        alert = {}
        severity = {}
        ack = {}
        notified = {}
        alert_type = {}
        cursor.execute('''SELECT rowid, * FROM alerts WHERE ack = 0 AND alert_type = "initial"''')
        ackable_alerts = cursor.fetchone()
        if ackable_alerts is None:
            print "There are no unackowledged initial alerts at this time\n"
        else:
            cursor.execute('''SELECT rowid, * FROM alerts WHERE ack = 0 AND alert_type = "initial"''')
            for row in cursor:
                alert_id = row['rowid']
                timestmp[alert_id] = row['alert_time']
                hostname[alert_id] = row['hostname']
                alert[alert_id] = row['message']    
                severity[alert_id] = row['severity']
                notified[alert_id] = row['notified']
                alert_type[alert_id] = row['alert_type']
            for alertid in timestmp:
                sql_str = "UPDATE alerts SET ack = 1 where rowid = %s" % (alertid)
                cursor.execute(sql_str)
                db.commit()
        db.close()
    except Exception as e:
        print "%s\n" % e

if __name__ == "__main__":
    main()
    sys.exit(0)


