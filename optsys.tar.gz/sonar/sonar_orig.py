#!/usr/bin/python

## sonor.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copyright and Intellectual Property Rights. For EYES Only!
#
# Simple ONline Active Recon (S.ON.A.R) is a program to detect and send realtime 
# status on an online device to aid in identification of devices on a network
# Built exclusively for the Recon Sentinel System


import sys
sys.path.insert(0, "/opt/system/")
import os
import signal
#import datetime
import time
#import getopt
import sqlite3
from core import functions
#import requests
#import json
import daemon

try:
    target_ip = sys.argv[1]
except Exception, e:
    print "sonar requires an argument: %s\n" % (e)
    sys.exit(0)


class ServiceExit(Exception):
    pass

def signal_term_handler(signal, frame):
    raise ServiceExit
    #print "got SIGTERM"

def sonar(target_ip):
    sonar_result = os.system("ping -c 1 -W 1 " + target_ip  + " > /dev/null 2>&1")
    time.sleep(1)
    return sonar_result

def sonar2(target_ip):
    sonar_result = os.system("ping -c 2 -W 1 " + target_ip  + " > /dev/null 2>&1")
    time.sleep(1)
    return sonar_result

def main(target_ip):
    signal.signal(signal.SIGTERM, signal_term_handler)
    sonar_result = 0
    try:
        while True:
            sonar_result = sonar(target_ip)
            if sonar_result:
                functions.display_lcd("SONAR DETECTED", "A CHANGE...")
                asd = functions.set_systemstatus("SONAR DETECTED A CHANGE - TESTING", "7")
                sonar_result2 = sonar2(target_ip)
                if sonar_result2:
                    asd = functions.set_systemstatus("SONAR STOPPED - DEVICE IS OFFLINE", "1")
                    functions.display_lcd("SONAR STOPPED", "DEVICE OFFLINE")
                    sys.exit(0)
            else:
                functions.display_lcd("SONAR ACTIVE", "DEVICE ONLINE")
                asd = functions.set_systemstatus("SONAR ACTIVE - DEVICE IS ONLINE", "7")
    except ServiceExit:
        functions.display_lcd("SONAR STOPPED", "BY USER REQUEST")
        sys.exit(0)

def run():
    with daemon.DaemonContext():
        main(target_ip)


if __name__ == '__main__':
    #run()
    main(target_ip)
