#!/usr/bin/python
## sonar_daemon.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copytight and Intellectual Property Rights. For EYES Only!
#
# stop_sonar will stop sonars as needed
# version 1.1 - 5/4/2017

import sys
sys.path.insert(0, "/opt/system/")
import os
import time
#import sqlite3
from core import functions

try:
    cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep sonar.py | /bin/grep -v stop_sonar.py | /usr/bin/awk '{print $2}'"
    pid = functions.cmdline(cmd)
    pid = str(pid.rstrip())
    while pid:
        cmd = "/bin/kill -15 %s" % (pid)
        killit = functions.cmdline(cmd)
        cmd = "/bin/ps aux | /bin/grep -v grep | /bin/grep sonar.py | /bin/grep -v stop_sonar.py | /usr/bin/awk '{print $2}'"
        pid = functions.cmdline(cmd)
        pid = str(pid.rstrip())
        time.sleep(0.5)
    sys.exit(0)
except Exception as e:
    print e
