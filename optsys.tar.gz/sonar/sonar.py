#!/usr/bin/python

## sonor.py - Copyright 2017 Cybersecurity Defense Solutions, LLC ALL RIGHTS RESERVED
# This work is protected by copyright and Intellectual Property Rights. For EYES Only!
#
# Simple ONline Active Recon (S.ON.A.R) is a program to detect and send realtime 
# status on an online device to aid in identification of devices on a network
# Built exclusively for the Recon Sentinel System


from axonchisel.handoff.object import Ax_Handoff
import sys
sys.path.insert(0, "/opt/system/")
import os
import signal
import time
import sqlite3
from core import functions
import requests
from requests.auth import HTTPBasicAuth
import sqlite3
import json

dbfile = "/opt/system/agent/agent.db"
try:
    db = sqlite3.connect(dbfile)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
except:
    print "Error connecting to dbfile: %s\n" % (dbfile)
    sys.exit(0)

try:
    sql = "SELECT * FROM agent_config"
    cursor.execute(sql)
    for row in cursor:
        deviceid = row['deviceid']
        password = row['password']
        sharedsecret = row['shared_secret']
except Exception as e:
    print "agent_config: %s\n" % e
    sys.exit(0)

try:
    target_ip = sys.argv[1]
except Exception, e:
    print "sonar requires an argument: %s\n" % (e)
    sys.exit(0)

def get_command():
    data1 = "{\"deviceid\": \"%s\", \"password\": \"%s\", \"ask\": \"getcmd\"}" % (deviceid, password)
    encdata = Ax_Handoff.encode(data1, sharedsecret)
    api = functions.get_apiurl()
    url = "%s/_cmd/%s" % (api, encdata)
    headers = {}
    res = requests.get(url, auth=HTTPBasicAuth(deviceid, password))
    json_data = Ax_Handoff.decode(res.text, sharedsecret)
    return json_data

def ack_cmd(cmd_id):
    api = functions.get_apiurl()
    url = "%s/_agent/script/ack" % (api)
    data = "{\"cmd_id\": \"%s\", \"deviceid\": \"%s\", \"password\": \"%s\"}" % (cmd_id, deviceid, password)
    api_response = functions.call_post_api(url, data)
    if api_response == "OK":
        #print "Got OK ACK, Command Complete"
        return True
    else:
        print "There is an issue with command id: %s : %s" % (cmd_id, api_response)
        return False

def stop_sonar():
    cmd = "/opt/system/sonar/stop_sonar.py"
    asd = functions.cmdline(cmd)


class ServiceExit(Exception):
    pass

def signal_term_handler(signal, frame):
    raise ServiceExit
    #print "got SIGTERM"

def sonar(target_ip):
    sonar_result = os.system("ping -c 1 -W 1 " + target_ip  + " > /dev/null 2>&1")
    time.sleep(1)
    return sonar_result

def sonar2(target_ip):
    cmd = "/usr/bin/nmap -sP %s | /bin/grep \"1 host up\"" % (target_ip) 
    sonar_result = functions.cmdline(cmd)
    time.sleep(1)
    return sonar_result

def main(target_ip):
    signal.signal(signal.SIGTERM, signal_term_handler)
    sonar_result = 0
    try:
        while True:
            sonar_result = sonar(target_ip)
            if sonar_result:
                sonar_result2 = sonar2(target_ip)
                if not sonar_result2:
                    asd = functions.set_systemstatus("SONAR STOPPED - DEVICE IS OFFLINE", "1")
                    functions.display_lcd("SONAR STOPPED", "DEVICE OFFLINE")
                    sys.exit(0)
                else:
                    functions.display_lcd("SONAR ACTIVE", "DEVICE IS ONLINE")
                    asd = functions.set_systemstatus("SONAR ACTIVE, DEVICE ONLINE", "7")
            else:
                functions.display_lcd("SONAR ACTIVE", "DEVICE ONLINE")
                asd = functions.set_systemstatus("SONAR ACTIVE - DEVICE IS ONLINE", "7") 
            command = get_command()
            resp = json.loads(command)
            if resp['cmd'] == "stop_sonar":
                asd = functions.set_systemstatus("Stopping SONAR", "1")
                ack_status = ack_cmd(resp['cmd_id'])
                asd = stop_sonar()

    except ServiceExit:
        functions.display_lcd("SONAR STOPPED", "BY USER REQUEST")
        functions.display_lcd("DEVICE ID:", deviceid)
        sys.exit(0)

if __name__ == '__main__':
    main(target_ip)
